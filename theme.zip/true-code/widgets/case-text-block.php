<?php

class Case_text_block extends WP_Widget {

	// Регистрация виджета используя основной класс
	function __construct() {
		parent::__construct(
			'',
			'Текстовый блок',
			array( 
				'description' => 'Для оформления кейса', 
				/*'classname' => 'my_widget',*/ 
			)
		);
	}

	/**
	 * Вывод виджета во Фронт-энде
	 *
	 * @param array $args     аргументы виджета.
	 * @param array $instance сохраненные данные из настроек
	 */
	function widget( $args, $instance ) {
		$title = apply_filters( 'widget_title', $instance['title'] );
		$description = apply_filters( 'widget_description', $instance['description'] );
		$site = apply_filters( 'widget_site', $instance['site'] );
		$alias = apply_filters( 'widget_alias', $instance['alias'] );

		// echo $args['before_widget'];
		?>
			<div class="container container--sm">
			    <div class="case__text-block">
			    	<?php 
			    		if(!empty($title)){
			    			echo '<strong class="case__heading">'.$title.'</strong>';
			    		}

			        	if(!empty($description)){
			        		echo wpautop($description);
			        	}

			        	if(!empty($site)){
			        		echo '<p class="text-center"><cite><a href="'.$site.'" class="case__link">'.(!empty($alias) ? $alias : $site).'</a></cite></p>';
			        	} 
			        ?>
			    </div>
			</div>
		<?php
		// echo $args['after_widget'];
	}

	/**
	 * Админ-часть виджета
	 *
	 * @param array $instance сохраненные данные из настроек
	 */
	function form( $instance ) {
		$title = @ $instance['title'] ?: '';
		$description = @ $instance['description'] ?: '';
		$site = @ $instance['site'] ?: '';
		$alias = @ $instance['alias'] ?: '';
		?>
		<p>
			<label for="<?php echo $this->get_field_id( 'title' ); ?>"><?php _e( 'Заголовок:' ); ?></label> 
			<input class="widefat" id="<?php echo $this->get_field_id( 'title' ); ?>" name="<?php echo $this->get_field_name( 'title' ); ?>" type="text" value="<?php echo esc_attr( $title ); ?>">
		</p>

		<p>
			<label for="<?php echo $this->get_field_id( 'description' ); ?>"><?php _e( 'Текст:' ); ?></label> 
			<textarea class="widefat" id="<?php echo $this->get_field_id( 'description' ); ?>" name="<?php echo $this->get_field_name( 'description' ); ?>" rows="5"><?php echo esc_attr( $description ); ?></textarea> 
		</p>

		<p> 
			Для вставки специально оформленной ссылки на внешний сайт. Оставить пустым, если не используется <br>
			<input class="widefat" id="<?php echo $this->get_field_id( 'site' ); ?>" name="<?php echo $this->get_field_name( 'site' ); ?>" type="text" value="<?php echo esc_attr( $site ); ?>" placeholder="Ссылка на сайт (http://www.site.ru)">
		</p>
		<p> 
			<input class="widefat" id="<?php echo $this->get_field_id( 'alias' ); ?>" name="<?php echo $this->get_field_name( 'alias' ); ?>" type="text" value="<?php echo esc_attr( $alias ); ?>" placeholder="Алиас ссылки (Название сайта)">
		</p>
		
		<?php 
	}

	/**
	 * Сохранение настроек виджета. Здесь данные должны быть очищены и возвращены для сохранения их в базу данных.
	 *
	 * @see WP_Widget::update()
	 *
	 * @param array $new_instance новые настройки
	 * @param array $old_instance предыдущие настройки
	 *
	 * @return array данные которые будут сохранены
	 */
	function update( $new_instance, $old_instance ) {
		$instance = array();
		$instance['title'] = ( ! empty( $new_instance['title'] ) ) ? strip_tags( $new_instance['title'] ) : get_the_title($post_id);
		$instance['description'] = ( ! empty( $new_instance['description'] ) ) ? strip_tags( $new_instance['description'] ) : '';
		$instance['site'] = ( ! empty( $new_instance['site'] ) ) ? strip_tags( $new_instance['site'] ) : '';
		$instance['alias'] = ( ! empty( $new_instance['alias'] ) ) ? strip_tags( $new_instance['alias'] ) : '';

		return $instance;
	}
} 


// регистрация в WordPress
function register_foo_widget() {
	register_widget( 'Case_text_block' );
}
add_action( 'widgets_init', 'register_foo_widget' );