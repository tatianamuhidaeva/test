<article class="blog-card <?php echo $blog_card['css_class']; ?>">
    <div class="blog-card__img">
        <?php 
            if($blog_card['img_link']){
                echo '<a href="'.get_the_permalink().'"><img src="'.get_the_post_thumbnail_url($post, 'post-thumb').'" alt=""></a>';
            } else {
                echo '<img src="'.get_the_post_thumbnail_url($post, 'post-thumb').'" alt="">';
            }
        ?>
    </div>
    <div class="blog-card__body">

        <?php if($blog_card['blur']): ?>
        <div class="blog-card__blur">
            <img src="<?php echo get_the_post_thumbnail_url($post, 'post-thumb'); ?>" alt="">
        </div>
        <?php endif; ?>

        <div class="blog-card__content">
            <?php if($blog_card['date']): ?>
            <small class="blog-card__date <?php echo $blog_card['date']['css_class']; ?>"><?php the_date(' j F Y'); ?></small>
            <?php endif; ?>

            <?php 
                if($blog_card['title']): 
                    echo '<'.$blog_card['title']['tag'].' class="blog-card__title '.$blog_card['title']['css_class'].'">';
                    if($blog_card['title']['link']) {
                        echo '<a href="'.get_the_permalink().'">'.get_the_title().'</a>';
                    } else {
                        echo get_the_title();
                    }
                    echo '</'.$blog_card['title']['tag'].'>';
                endif;
            ?>

            <?php if($blog_card['excerpt'] && has_excerpt()): ?>
            <div class="blog-card__excerpt">
                <?php the_excerpt(); ?>
            </div>
            <?php endif; ?>
        </div>
    </div>
</article>