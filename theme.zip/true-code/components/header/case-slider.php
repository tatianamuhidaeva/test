<div class="case-slider" role="slider">
    <div class="case-slider__container">
    	<div class="case-slider__track">
    		<div class="case-slider__item case-slider__placeholder">
    			<div class="case-slider__placeholder-inner">
    				<img src="<?php bloginfo('template_url')?>/img/general/eye.png" alt="">
    				<a href="<?php echo get_site_url().'/portfolio'; ?>" class="btn btn--a case-slide__btn">Все проекты</a>
    			</div>
    		</div>

    		<div class="case-slider__item case-slider__item--prev">
                <?php get_template_part('components/header/slides/easy'); ?>
            </div>

            <div class="case-slider__item case-slider__item--current">
                <?php get_template_part('components/header/slides/kiwi'); ?>
            </div>

            <div class="case-slider__item case-slider__item--next">
                <?php get_template_part('components/header/slides/behance'); ?>
            </div>

    		<div class="case-slider__item case-slider__placeholder">
    			<div class="case-slider__placeholder-inner">
    				<img src="<?php bloginfo('template_url')?>/img/general/eye.png" alt="">
    				<a href="<?php echo get_site_url().'/portfolio'; ?>" class="btn btn--a case-slide__btn">Все проекты</a>
    			</div>
    		</div>
    	</div>
    </div>
    <div class="case-slider__arrows" rel="nofollow">
        <span class="case-slider__arrow case-slider__arrow--light case-slider__arrow--left" role="button"></span>
        <span class="case-slider__arrow case-slider__arrow--light case-slider__arrow--right" role="button"></span>
    </div>
</div>