<div class="case-slide">
	<div class="invisible">
		<h3>Easy School</h3>
	</div>

	<div class="case-slide__animate easy-case" rel="nofollow" role="presentation">
		<img src="<?php bloginfo('template_url')?>/img/case-slider/easy_1.png" alt="Часть составного изображения" class="easy-case__img easy-case__img--layer1">      
		<img src="<?php bloginfo('template_url')?>/img/case-slider/easy_2.png" alt="Часть составного изображения" class="easy-case__img easy-case__img--layer2">      
		<img src="<?php bloginfo('template_url')?>/img/case-slider/easy_3.png" alt="Часть составного изображения" class="easy-case__img easy-case__img--layer3"> 
	</div>

	<div class="case-slide__preview" rel="nofollow" role="presentation">
		<picture>
			<source type="image/webp" srcset="<?php bloginfo('template_url')?>/img/case-slider/bundle-easy-1x.webp 1x, <?php bloginfo('template_url')?>/img/case-slider/bundle-easy-2x.webp 2x">
			<img srcset="<?php bloginfo('template_url')?>/img/case-slider/bundle-easy-1x.png 1x, <?php bloginfo('template_url')?>/img/case-slider/bundle-easy-2x.png 2x" src="<?php bloginfo('template_url')?>/img/case-slider/bundle-easy-2x.png" alt="Превью кейса">
		</picture>
	</div>
	<a href="<?php echo get_site_url().'/case/easy-school/'; ?>" class="btn btn--a case-slide__btn">Посмотри кейс</a>
</div>