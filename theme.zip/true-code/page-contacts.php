<?php get_header(); ?>
<?php
    # Выводит шапку сайта. (components/header)
    get_template_part('components/header/view');
?>

<section class="section contacts contacts--purple">
    <div class="container">
        <h2 class="section__title section__title--while">Контакты</h2>
        <div class="contacts__grid contacts__grid--align-center contacts__grid--offset-y">
            <div class="contacts__col contacts__brand">
                <adress class="vcard contacts__blank contacts__blank--tiny contacts__blank--tablet-offset-lg">
                    <div class="adr contacts__adr">
                        <span class="adr__state locality">Россия, г. Иркутск</span>
                        <span class="adr__street street-address">ул. 1-я Красноказачья, 119, 3 этаж</span>
                    </div>
                    <div class="contacts__tel">
                        <a href="callto:+7(3952)96-26-91" class="tel">+7(3952)96-26-91</a>
                    </div>
                    <div class="contacts__email">
                        <div class="contacts__heading">
                            <strong>Сотрудничество</strong> 
                        </div>
                        <a href="mailto:support@t-code.ru" class="email">support@t-code.ru</a>
                    </div>
                </adress>
            </div>
            <div class="contacts__col contacts__page-info">
                <p>Мы занимаемся разработкой веб-сайтов различной сложности под индивидуальные задачи клиентов. Производим комплексные услуги: от проектирования до рекламы и поддержки готового продукта.</p>
                <a href="<?php echo get_site_url().'/portfolio'; ?>" class="btn contacts__portfolio-link">Смотреть портфолио</a>
            </div>
        </div>
    </div>
    <?php get_template_part('components/contacts/map'); ?>
</section>

<?php
    # выводит секцию с формой обратной связи. (components/bid)
    bid(array(
        'visible_title' => true
    ));
?>
<?php get_footer(); ?>