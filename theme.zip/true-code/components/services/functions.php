<?php
	function services($args = array()) {
		
		$default_args = array(
			'title' => 'Что мы делаем?',
			'visible_title' => true,

		);
		$args = array_replace_recursive($default_args, $args);

		set_query_var('services', $args);
		get_template_part('components/services/services');
	}