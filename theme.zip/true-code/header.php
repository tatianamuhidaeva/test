<!doctype html>
<html lang="ru">
    <head>
        <?php wp_head(); ?>
    </head>
	<?php get_template_part('components/loader/loader'); ?>
    <body class="page">
    	<div class="clip">
        