<?php
	function page_header($args = array()) {

		$menu_location = get_nav_menu_locations();

		# Настройки Шапки сайта по умолчанию
		$default_args = array(
			'title' => 'Верный код - создание сайтов, веб-дизайн, СММ',
			'css_class' => 'page__header',
			'navbar' => array(
				'css_class' => 'header__navbar',
				'logo' => array(
					'image' => get_bloginfo('template_url').'/img/general/logo_simple.svg',
					'image_alt' => get_bloginfo('template_url').'/img/general/logo_simple_alt.svg',
					'alt' => '',
					'title' => 'True Code',
					'subtitle' => 'Студия веб-разработки',
					'link' => get_site_url(),
					'css_class' => 'header__logo'
				),
				'nav' => array(
					'css_class' => 'header__nav'
				),
				'menu' => array(
					'css_class' => 'header__menu',
					'location' => $menu_location['header_menu']
				),
				'contacts' => array(
					'tel' => '+7(3952)96-26-91',
					'email' => 'support@t-code.ru',
					'css_class' => 'header__contacts'
				),
				'callback' => array(
					'action' => '#',
					'css_class' => 'header__callback'
				)
			),
			'case' => array(
				'title' => 'Кейсы'
			),
			'hero' => array(
				'title' => '',
				'image' => '',
				'video' => false
			)
		);
		$args = array_replace_recursive($default_args, $args);

		set_query_var('page_header', $args);
		get_template_part('components/header/header');
	}