<div class="slider__track">
    <?php 
        $steps = CFS()->get( 'step_loop' ); 
        for ($i = 0; $i < count($steps); $i++) { 
            switch ($i) {
                case '0':
                    $slide_pos = 'slider__item--current';
                    break;

                 case '1':
                    $slide_pos = 'slider__item--next';
                    break;
                
                default:
                    $slide_pos = '';
                    break;
            }

            echo case_slider_item(array(
                'i' => ($i < 10 ? '0'.($i+1): ($i+1)),
                'title' => $steps[$i]['step_title'],
                'text' => $steps[$i]['step_description'],
                'img_id' => $steps[$i]['step_img'],
                'css_class' => $slide_pos
            ));
        }
    ?>
</div>
<div class="slider__arrows" rel="nofollow">
    <span class="slider__arrow slider__arrow--dark slider__arrow--left" role="button"></span>
    <span class="slider__arrow slider__arrow--dark slider__arrow--right" role="button"></span>
</div>
   