<div class="case-card">
    <div class="case-card__img" data-tilt data-tilt-maxTilt="20" data-tilt-speed="700" data-tilt-perspective="2500">
        <a href="<?php the_permalink(); ?>"><img src="<?php echo get_field('case_img')['sizes']['case-thumb']; ?>" alt="<?php get_field('case_img')['alt']; ?>"></a>
    </div>
    <div class="case-card__blur">
        <img src="<?php echo get_field('case_img')['sizes']['case-thumb']; ?>" alt="<?php get_field('case_img')['alt']; ?>">
    </div>
    <div class="case-card__info">
        <h3 class="case-card__title"><?php get_field('case_title') ? the_field('case_title') : the_title(); ?></h3>
        <?php if(get_field('case_subtitle')): ?>
            <small class="case-card__subtitle"><?php the_field('case_subtitle'); ?></small>
        <?php endif; ?>
    </div>
</div>