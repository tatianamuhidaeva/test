<?php get_header(); the_post(); ?>
<?php 
    # Выводит шапку сайта. (components/header)
    page_header(array(
        'title' => get_the_title(),
        'css_class' => 'header--b page__header',
        'hero' => false,
        'case' => false
    )); 
?>
<section class="section blog">
    <div class="container">
        <div class="blog__layout">
            <main class="blog__main">

                <?php 
                    echo blog_card(array(
                        'blur' => true,
                        'img_link' => false,
                        'date' => array(
                            'css_class' => 'blog-card__date--inverse'
                        ),
                        'title' => array(
                            'tag' => 'strong',
                            'link' => false
                        )
                    )); 
                ?>

                <article class="post blog__article">
                    <?php the_content(); ?>
                    
                    <!-- <iframe class="post__video" width="560" height="315" src="https://www.youtube.com/embed/7ZO2RTMNSAY" frameborder="0" allow="autoplay; encrypted-media" allowfullscreen></iframe> -->
                    
                </article>
                <nav class="blog__share">
                    <div class="share">
                        <strong class="share__title">Зашарить пост:</strong>
                        <a href="https://vk.com/share.php?url=<?php echo get_the_permalink(); ?>" target="_blank" class="share__link share__link--vk">ВК</a>
                        <a href="https://www.facebook.com/sharer/sharer.php?u=<?php echo get_the_permalink(); ?>" target="_blank" class="share__link share__link--fb">FB</a>
                        <a href="http://www.odnoklassniki.ru/dk?st.cmd=addShare&st.s=1&st._surl=<?php echo get_the_permalink(); ?>" target="_blank" class="share__link share__link--ok">OK</a>
                        <a href="http://twitter.com/share?url=<?php echo get_the_permalink(); ?>" target="_blank" class="share__link share__link--tw">ТВИТНУТЬ</a>
                    </div>
                </nav>

                <?php 
                    $args = array(
                        'numberposts' => 2,
                        'orderby'     => 'rand',
                        'order'       => 'DESC',
                        'exclude'     => get_the_ID(),
                        'post_type'   => 'post'
                    );
                    $posts = get_posts( $args );

                    if($posts):
                ?>
                    <section class="section read-more">
                        <h2 class="read-more__title">Читать далее</h2>
                        <div class="read-more__grid">
                        <?php foreach($posts as $post): setup_postdata($post); ?>
                            <div class="read-more__item">
                                <?php 
                                    echo blog_card(array(
                                        'title' => array(
                                            'css_class' => 'blog-card__title--sm my-0',
                                            'tag' => 'h3'
                                        ),
                                        'excerpt' => false,
                                        'date' => false
                                    )); 
                                ?>
                            </div>
                        <?php endforeach; ?>
                        </div>
                    </section>
                <?php endif; ?>

                <nav class="blog__nav">
                    <a href="<?php echo get_site_url().'/blog'; ?>" class="btn btn--back blog__back blog__back--center">Назад</a>
                </nav>
            </main>
            <aside class="blog__aside">
                <?php get_template_part('components/feedback/envelope','min'); ?>
            </aside>
        </div>
    </div>
</section>
<?php get_footer(); ?> 