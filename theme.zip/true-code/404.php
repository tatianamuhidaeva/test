<?php get_header(); ?>
<h1 class="invisible">Страница не найдена</h1>
<div class="page-404">
    <video class="page-404__video" autoplay buffered loop muted preload banner="<?php echo get_bloginfo('template_url').'/img/general/404.jpg'; ?>">
        <source src="<?php echo get_bloginfo('template_url').'/img/video/404.mp4'; ?>" type="video/mp4">
        <source src="<?php echo get_bloginfo('template_url').'/img/video/404.webm'; ?>" type="video/webm">
        <img src="<?php echo get_bloginfo('template_url').'/img/general/404.jpg'; ?>" alt="Команда веб-студии Верный Код">     
    </video>
    <div class="page-404__overlay">
        <div class="page-404__logo">
            <img src="<?php echo get_bloginfo('template_url').'/img/general/logo_w.png'; ?>" alt="">
        </div>
        <div class="page-404__body">
            <div class="page-404__title">Котик<br>не смог найти<br>страницу!</div>
            <div class="page-404__text">Но мы всегда ждем вашего письма - <a href="mailto:support@t-code.ru">support@t-code.ru</a></div>
            <div class="page-404__text">И готовы ответить по телефону - <a href="callto:+7 (3952) 96-26-91">+7 (3952) 96-26-91</a></div>
            <a href="<?php echo get_site_url(); ?>" class="page-404__btn">Перейти на главную страницу</a>
        </div>
    </div>
</div>
<?php get_footer(); ?>      