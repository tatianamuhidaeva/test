<?php
	function blog_card($args = array()) {
		
		$default_args = array(
			'css_class' => '',
			'blur' => false,
			'img_link' => true,
			'date' => array(
				'css_class' => ''
			),
			'title' => array(
				'css_class' => '',
				'tag' => 'h2',
				'link' => true
			),
			'excerpt' => true,
		);
		$args = array_replace_recursive($default_args, $args);

		ob_start();
		set_query_var('blog_card', $args);
		get_template_part('components/blog-card/blog-card');
		$component = ob_get_contents();
		ob_end_clean();

		return $component;
	}