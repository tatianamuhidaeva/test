<div class="case-slide">
    <div class="invisible">
        <h3>Софора</h3>
        <small>мед. центр</small>
    </div>
    <div class="case-slide__animate sofora-case" rel="nofollow" role="presentation">
        <img src="<?php bloginfo('template_url')?>/img/case-slider/sofora-balloon.png" alt="" class="sofora-case__img sofora-case__img--layer0">      
        <img src="<?php bloginfo('template_url')?>/img/case-slider/sofora-foo.png" alt="" class="sofora-case__img sofora-case__img--layer1">      
        <img src="<?php bloginfo('template_url')?>/img/case-slider/sofora-statoscop.png" alt="" class="sofora-case__img sofora-case__img--layer2">      
        <img src="<?php bloginfo('template_url')?>/img/case-slider/sofora-card.png" alt="" class="sofora-case__img sofora-case__img--layer3">      
    </div>
    <div class="case-slide__preview" rel="nofollow" role="presentation">
        <picture>
            <source type="image/webp" srcset="<?php bloginfo('template_url')?>/img/case-slider/bundle-sofora-1x.webp 1x, <?php bloginfo('template_url')?>/img/case-slider/bundle-sofora-2x.webp 2x">
            <img srcset="<?php bloginfo('template_url')?>/img/case-slider/bundle-sofora-1x.png 1x, <?php bloginfo('template_url')?>/img/case-slider/bundle-sofora-2x.png 2x" src="<?php bloginfo('template_url')?>/img/case-slider/bundle-sofora-2x.png" alt="Превью кейса">
        </picture>
    </div>
    <a href="<?php echo get_site_url().'/case/sofora'; ?>" class="btn btn--a case-slide__btn">Посмотри кейс</a>
</div>