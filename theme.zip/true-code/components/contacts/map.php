<div id="map" class="map contacts__map"></div>
<script src="https://api-maps.yandex.ru/2.1/?lang=ru_RU" type="text/javascript"></script>
<script>
	ymaps.ready(function () {
		var myMap = new ymaps.Map('map', {
			center: [52.2681,104.3295],
			zoom: 17,
			controls: []
		});
		myMap.geoObjects.add(new ymaps.Placemark([52.2681,104.3295], {
			balloonContentBody: "ул. 1-я Красноказачья, 119, 3 этаж",
			iconCaption: "Верный код"
		}, 
		{
			preset: 'islands#yellowIcon'
		}));
		myMap.behaviors.disable('scrollZoom')
	});
</script>