<div class="case-slide">
    <div class="invisible">
        <h3>Кирпич<br>в Иркутске</h3>
        <small>сайт компании</small>
    </div>
    <div class="case-slide__animate  kirvi-case" rel="nofollow" role="presentation">
        <img src="<?php bloginfo('template_url')?>/img/case-slider/kirvi-house.png" alt="" class="kirvi-case__img kirvi-case__img--layer1">       
        <img src="<?php bloginfo('template_url')?>/img/case-slider/kirvi-bricks.png" alt="" class="kirvi-case__img kirvi-case__img--layer2">
        <div class="case-slide__title">Кирпич<br>в Иркутске</div>      
    </div>
    <div class="case-slide__preview" rel="nofollow" role="presentation">
        <picture>
            <source type="image/webp" srcset="<?php bloginfo('template_url')?>/img/case-slider/bundle-kirvi-1x.webp 1x, <?php bloginfo('template_url')?>/img/case-slider/bundle-kirvi-2x.webp 2x">
            <img srcset="<?php bloginfo('template_url')?>/img/case-slider/bundle-kirvi-1x.png 1x, <?php bloginfo('template_url')?>/img/case-slider/bundle-kirvi-2x.png 2x" src="<?php bloginfo('template_url')?>/img/case-slider/bundle-kirvi-2x.png" alt="Превью кейса">
        </picture>
    </div>
    <a href="<?php echo get_site_url().'/case/kirvi'; ?>" class="btn btn--a case-slide__btn">Посмотри кейс</a>
</div>