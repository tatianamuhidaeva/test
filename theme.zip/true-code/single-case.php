<?php get_header(); the_post(); ?>
<?php
    # Выводит шапку сайта. (components/header)
    page_header(array(
        'title' => get_the_title(),
        'css_class' => 'header--c page__header',
        'hero' => array(
            'title' => get_the_title(),
            'image' => get_the_post_thumbnail_url($post, 'hero')
        ),
        'case' => false,
        'navbar' => array(
            'css_class' => 'header__navbar header__navbar--above'
        )
    )); 
?>
<section class="case">
    <?php if(get_field('case_description')): ?>
    <div class="container container--sm">
        <div class="case__description">
            <?php echo get_field('case_description'); ?>
        </div>
    </div>
    <?php endif; ?>

    <?php the_content(); ?>
</section>

<?php 
    # выводит секцию с формой обратной связи. (components/feedback/bid)
    bid(array(
        'visible_title' => false
    ));
?>

<?php $next_post = get_next_post(false, '', 'portfolio'); ?>
<footer class="case-footer <?php echo empty($next_post) ? 'pb-10' : ''; ?>">
    <nav class="case-footer__nav">
        <a href="<?php echo get_site_url().'/portfolio'; ?>" class="btn btn--back btn--white case-footer__back">Назад</a>
    </nav>
    <?php if(!empty($next_post)): ?>
    <div class="case-footer__next">
        <a href="<?php echo get_the_permalink($next_post->ID); ?>" class="case-footer__proj-link">
            <strong class="case-footer__title">Следующий проект</strong>
            <img src="<?php echo get_field('next_img', $next_post->ID)['sizes']['next-thumb']; ?>" alt="<?php echo get_field('case_img')['alt']; ?>">
        </a>
    </div>
    <?php endif; ?>
</footer>
<?php get_footer(); ?>