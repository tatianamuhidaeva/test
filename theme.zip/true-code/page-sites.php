<?php get_header(); the_post(); ?>
<?php 
    # Выводит шапку сайта. (components/header)
    get_template_part('components/header/view'); 
?>

<section class="case">
    <div class="container container--sm">
        <div class="case__description">
            <p>Зачастую предприниматели откладывают разработку сайта своего бизнеса в дальний угол: нет времени, нет денег, нет уверенности, что это вложение будет полезным и принесет клиентов. Но на самом деле, развивать свой бизнес в интернете – это один из самых эффективных методов  по привлечению клиентов. А все потому, что ваши услуги ищут в интернете!</p>
            <p>Для разработки сайта вам потребуется лишь несколько действий: рассказать нам о вашем бизнесе, поделиться своими идеями и подготовить необходимую информацию. Все это вы сможете сделать, заполнив наш бриф и отправив его нам.</p>
            <p>Исходя из брифа, мы озвучим стоимость вашего проекта в течение 2 рабочих дней.</p>
            <a href="<?php bloginfo('template_url')?>/brif.docx" class="btn btn--d case__brif" onclick="ym(38838170, 'reachGoal', 'brif'); return true;" download>Скачать бриф</a>
        </div>
    </div>
    <div class="container container--sm mt-6 mt-10--notebook">
       <div class="case__text-block clearfix">
            <h2 class="case__title case__title--center">Этапы разработки</h2>
            <p>Вам кажется, что разработка сайта – это очень сложно и займет у вас много времени? Поверьте, это не так. Предлагаем вам подробнее познакомиться с этапами разработки сайта, и вы поймете, что разработка сайта – это по большей части наша работа и наши предложения.</p>
       </div>
    </div>
    
    <div class="slider case__slider">
        <div class="slider__container mb-5 mb-20--tablet">
            <?php get_template_part('components/case-slider/slider'); ?>
        </div>
    </div>

    <div class="container container--sm">
        <div class="case__text-block">
            <h2 class="case__title case__title--center">Что мы можем вам предложить</h2>
            <h3 class="case__subtitle text-center">Современный индивидуальный дизайн</h3>
            <p>Наши специалисты всегда в курсе последних тенденций и нововведений в веб-дизайне и веб-разработке. Мы всегда используем актуальные технологии и приемы, учитывая при этом золотые основы типографики и дизайна.</p>
            <p>Мы понимаем бизнес-задачи каждого из наших клиентов, знаем, как сделать сайт запоминающимся и в то же время удобным и прибыльным.</p>
        </div>
    </div>

    <div class="common-block common-block--design" rel="nofollow" role="presentation">
        <div class="container">
            <span id="site3" class="animated" rel="nofollow" role="presentation">
                <picture>
                    <source type="image/webp" srcset="<?php bloginfo('template_url')?>/img/general/site-3.webp">
                    <img src="<?php bloginfo('template_url')?>/img/general/site-3.png" alt="Пример сайта">
                </picture>
            </span>
            <span id="site2" class="animated" rel="nofollow" role="presentation">
                <picture>
                    <source type="image/webp" srcset="<?php bloginfo('template_url')?>/img/general/site-2.webp">
                    <img src="<?php bloginfo('template_url')?>/img/general/site-2.png" alt="Пример сайта">
                </picture>
            </span>
            <span id="site1" class="animated" rel="nofollow" role="presentation">
                <picture>
                    <source type="image/webp" srcset="<?php bloginfo('template_url')?>/img/general/site-1.webp">
                    <img src="<?php bloginfo('template_url')?>/img/general/site-1.png" alt="Пример сайта">
                </picture>
            </span>
        </div>
    </div>

    <div class="common-block common-block--nolimits">
        <span id="floor" class="animated" rel="nofollow" role="presentation">
            <picture>
                <source type="image/webp" srcset="<?php bloginfo('template_url')?>/img/general/floor.webp">
                <img src="<?php bloginfo('template_url')?>/img/general/floor.png" alt="Пример работы">
            </picture>
        </span>
        <div class="container">
            <div class="case__text-block">
                <h3 class="case__subtitle">Не боимся сложностей</h3>
                <p>С удовольствием беремся за самые сложные и нетиповые задачи. Помогаем структурировать и реализовывать необычные задумки. Знаем, как преподнести даже самые трудные услуги интересно и непринужденно. </p>
                <p>Всегда готовы реализовать любую из ваших идей: 3D модели, иллюстрации, видеоролики, анимация, сложное программирование. </p> 
            </div>
        </div>
    </div>

    <div class="common-block common-block--ux">
        <div class="container container--sm">
            <div class="case__text-block clearfix">
                <span id="am-phone" class="animated" rel="nofollow" role="presentation">
                    <picture>
                        <source type="image/webp" srcset="<?php bloginfo('template_url')?>/img/general/mamaeva-phone.webp">
                        <img src="<?php bloginfo('template_url')?>/img/general/mamaeva-phone.png" alt="Пример работы">
                    </picture>
                </span>
                
                <div class="pt-10--tablet">
                    <h3 class="case__subtitle">Удобство и простота в использовании</h3>
                    <p>Кроссбраузерность, адаптив и юзабилити – не просто слова для нас. Мы разрабатываем сайт, учитывая удобство его использования на всех устройствах.</p> 
                    <p>Изначально просчитываем до мелочей как адекватное отображение сайта на всех устройствах, так и правильное расположения блоков при уменьшении экранов.</p>
                </div>
            </div>
        </div>
    </div>

    <div class="common-block common-block--support">
        <span id="metrika" class="animated" rel="nofollow" role="presentation">
            <picture>
                <source type="image/webp" srcset="<?php bloginfo('template_url')?>/img/general/metrika.webp">
                <img src="<?php bloginfo('template_url')?>/img/general/metrika.png" alt="Пример работы">
            </picture>
        </span>
        
        <div class="container">
            <div class="case__text-block">
                <h3 class="case__subtitle">Поддержка и развитие проекта</h3>
                <p>Высоконагруженные проекты, такие как интернет-магазины, новостные сайты и дугие требуют постоянного мониторинга состояния и технической поддержки. Приходим на помощь в любой ситуации и исправляем любые проблемы с сайтом. </p>
                <p>С самого начала проекта мы продумываем дальнейшие действия по продвижению вашего бизнеса в интернете различными средствами: продвижение, контекстная реклама, СММ.</p>
                <p>Просчитываем планируемую посещаемость проекта и учитываем это при выборе конфигурации сервера.</p>
            </div>
        </div>
    </div>

    <div class="case-common case-common--am">
        <div class="case-common__inner">
            <span class="case-common__img case-common__img--am-1 animated" rel="nofollow" role="presentation">
                <picture>
                    <source type="image/webp" srcset="<?php bloginfo('template_url')?>/img/general/am-1.webp">
                    <img src="<?php bloginfo('template_url')?>/img/general/am-1.png" alt="Пример работы AM DESIGN LAB">
                </picture>
            </span>

            <span class="case-common__img case-common__img--am-2 animated" rel="nofollow" role="presentation">
                <picture>
                    <source type="image/webp" srcset="<?php bloginfo('template_url')?>/img/general/am-2.webp">
                    <img src="<?php bloginfo('template_url')?>/img/general/am-2.png" alt="Пример работы AM DESIGN LAB">
                </picture>
            </span>
            
            <div class="case-common__blank case-common__blank--lg ">
                <span class="case-common__logo" rel="nofollow" role="presentation">
                    <picture>
                        <source type="image/webp" srcset="<?php bloginfo('template_url')?>/img/general/am.webp">
                        <img src="<?php bloginfo('template_url')?>/img/general/am.png" alt="Пример работы AM DESIGN LAB">
                    </picture>
                </span>
                <div class="case-common__text">
                    <p>Например, как мы это сделали<br>для студии дизайна AM DESIGN LAB</p>
                    <a href="<?php echo get_site_url().'/case/am-designlab'; ?>" class="case-common__link">Посмотреть кейс</a>
                </div>
            </div>
        </div>
    </div>
</section>

<?php 
    # выводит секцию с формой обратной связи. (components/feedback/bid)
    bid(array(
        'visible_title' => false
    ));
?>

<footer class="case-footer pb-10">
    <nav class="case-footer__nav case-footer__nav--around">
        <a href="<?php echo get_site_url().'/smm'; ?>" class="btn btn--back btn--white case-footer__back">SMM</a>
        <a href="<?php echo get_site_url().'/design'; ?>" class="btn btn--next btn--white case-footer__next">Фирменный стиль</a>
    </nav>
</footer>

<?php get_footer(); ?>