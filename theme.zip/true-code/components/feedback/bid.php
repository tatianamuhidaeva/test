<section class="section bid">
    <div class="container">
        <h2 class="section__title <?php echo 'section__title--'.$bid['title_color']; ?> <?php echo $bid['visible_title'] ? '' : 'invisible'; ?>"><?php echo $bid['title']; ?></h2>
        <div class="bid__inner">
            <div class="bid__text">
                <p>Вы можете оставить нам заявку на наши услуги и мы с вами свяжемся в ближайшее время</p>
            </div>
            <form class="bid__form envelope">
            	<svg class="envelope__header" viewBox="0 0 433 90">
            		<polygon class="envelope__triangle" points="0,75 216.5,0 433,75"/>
            		<rect class="envelope__back" x="0" y="75" width="100%" height="15"/>
            		<rect class="envelope__letter" x="5%" y="55" width="90%" height="35"/>
            	</svg>
                <div class="envelope__body">
                    <div class="envelope__fieldset">
                        <label for="name" class="envelope__label">Имя</label>
                        <input type="text" id="name" name="name" class="envelope__form-control" required>
                    </div>
                    <div class="envelope__fieldset">
                        <label for="email" class="envelope__label">Email</label>
                        <input type="email" id="email" name="email" class="envelope__form-control" required>
                    </div>
                    <div class="envelope__fieldset">
                        <label for="phone" class="envelope__label">Телефон</label>
                        <input type="text" id="phone" name="phone" class="envelope__form-control" data-mask="+7(000)000-00-00" required>
                    </div>
                    <div class="envelope__fieldset">
                        <label for="services" class="envelope__label">Какие услуги вас интересуют?</label>
                        <select name="services" id="services" class="envelope__select-control">
                            <option value="Сайты">Сайты</option>
                            <option value="Контекстная реклама">Контекстная реклама</option>
                            <option value="Фирменный стиль">Фирменный стиль</option>
                            <option value="SMM">SMM</option>
                        </select>
                    </div>
                    <div class="envelope__fieldset">
                        <label for="message" class="envelope__label envelope__label--for-textarea">Комментарий</label>
                        <textarea name="message" id="message" rows="4" class="envelope__textarea-control"></textarea>
                    </div>
                </div>
                <div class="envelope__footer text-center">
                	<div class="envelope__fieldset">
                	    <label for="terms" class="envelope__label politica">
                	    	<input type="checkbox" name="terms" id="terms" class="invisible" value="Я принимаю политику конфиденциальности">
                	    	<span class="envelope__checkbox-control"></span>
                	    	Я принимаю политику конфиденциальности
                	    </label>
                	</div>
                    <input type="hidden" name="subject" value="Заявка на услуги">
                	<button type="submit" class="btn btn--a envelope__btn disabled" onclick="ym(38838170, 'reachGoal', 'open_form'); return true;">Отправить заявку</button>
                </div>
            </form>
        </div>
    </div>
</section>