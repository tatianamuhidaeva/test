<?php get_header(); the_post(); ?>
<?php 
    # Выводит шапку сайта. (components/header)
    get_template_part('components/header/view'); 
?>
<section class="section blog">
    <div class="container">
        <div class="blog__layout">
            <main class="blog__main">
                
                <article class="post blog__article">
                    <?php the_content(); ?>  
                </article>

                <nav class="blog__nav">
                    <a href="javascript:history.back()" class="btn btn--back blog__back blog__back--center">Назад</a>
                </nav>
            </main>
        </div>
    </div>
</section>
<?php get_footer(); ?> 