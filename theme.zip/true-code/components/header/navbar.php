<?php
    $navbar = $page_header['navbar'];
    $logo = $navbar['logo'];
    $nav = $navbar['nav'];
    $menu = $navbar['menu'];
    $contacts = $navbar['contacts'];
    $callback = $navbar['callback'];
?>

<div class="<?php echo $navbar['css_class']; ?>">

    <?php if($logo): ?>
        <div class="logo <?php echo $logo['css_class'];?>">
            <a href="<?php echo $logo['link']; ?>">
                <?php if(strpos($page_header['css_class'], 'header--b') !== false): ?>
                    <img src="<?php echo $logo['image_alt']; ?>" alt="<?php echo $logo['alt']; ?>" class="logo__img" width="145" height="69">
                <?php else: ?>
                    <img src="<?php echo $logo['image']; ?>" alt="<?php echo $logo['alt']; ?>" class="logo__img" width="145" height="69">
                <?php endif; ?>
                <span class="logo__description invisible">
                    <strong class="logo__title"><?php echo $logo['title']; ?></strong>
                    <small class="logo__subtitle"><?php echo $logo['subtitle']; ?></small>
                </span>
            </a>
        </div>
    <?php endif; ?>

    <?php if($nav): ?>
        <nav class="main-nav <?php echo $nav['css_class'];?>">
            <button class="header__nav-trigger main-nav__trigger">
                <span></span>
                <span></span>
                <span></span>
            </button>
            <ul class="site-menu <?php echo $menu['css_class'];?>">
                <?php
                    $menu_object = wp_get_nav_menu_object($menu['location']);
                    $menu_items = wp_get_menu_array( $menu_object );
                    foreach ( (array) $menu_items as $key => $menu_item ):
                        if(!empty($menu_item['submenu'])) {
                            $submenu = $menu_item['submenu'];
                            $submenu_items = '';
                            $active = false;
                            foreach ( (array) $submenu as $key => $submenu_item ): 
                                $submenu_items .= '<li class="site-menu__item"><a href="'.$submenu_item['url'].'" class="site-menu__link">'.$submenu_item['title'].'</a></li>';
                                if($post->ID == $submenu_item['ID'] && !$active) {
                                    $active = true;
                                }
                            endforeach;

                            echo '
                                <li class="site-menu__item">
                                    <a href="'.$menu_item['url'].'" class="site-menu__link '.($active ? 'site-menu__link--active' : '').'">'.$menu_item['title'].'</a>
                                    <ul class="site-menu__dropdown">'.$submenu_items.'</ul>
                                </li>';
                        } 
                        elseif(isset($menu_item['submenu'])) {
                            if($post->ID == $menu_item['ID']) {
                                echo '<li class="site-menu__item"><a href="'.$menu_item['url'].'" class="site-menu__link site-menu__link--active">'.$menu_item['title'].'</a></li>';
                            } else {
                                echo '<li class="site-menu__item"><a href="'.$menu_item['url'].'" class="site-menu__link">'.$menu_item['title'].'</a></li>';
                            }
                        }
                    endforeach;
                ?>
            </ul>
        </nav>
    <?php endif; ?>

    <?php if($contacts): ?>
        <div class="<?php echo $contacts['css_class'];?>">
            <div class="tel header__tel"><a href="callto:<?php echo $contacts['tel'];?>" onclick="ym(38838170, 'reachGoal', 'telefon'); return true;"><?php echo $contacts['tel'];?></a></div>
            <div class="email header__email"><a href="mailto:<?php echo $contacts['email'];?>" onclick="ym(38838170, 'reachGoal', 'mail'); return true;"><?php echo $contacts['email'];?></a></div>
        </div>
    <?php endif; ?>

    <?php if($callback): ?>
        <a href="#ask" class="callback <?php echo $callback['css_class'];?>" data-toggle="modal" onclick="ym(38838170, 'reachGoal', 'open_form'); return true;"><span>Есть вопросы?<br>Мы ответим</span></a>
    <?php endif; ?>
</div>