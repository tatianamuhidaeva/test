<section class="section services">
    <h2 class="section__title section__title--purple <?php echo $services['visible_title'] ? '' : 'invisible'; ?>"><?php echo $services['title']; ?></h2>
    <div class="slider services__slider" role="slider">
    	<div class="slider__container">
    		<div class="slider__track">
		        <div class="slider__item slider__item--current">
		            <div class="service">
		                <h3 class="service__title"><a href="<?= get_site_url(null,'/sites') ?>">Сайты</a></h3>
		                <p class="service__text"><span class="stroke stroke--pink">Создаем крутые интернет-магазины,</span> корпоративные сайты, рекламные лендинги</p>
		                <div class="service__preview service__preview--sites" rel="nofollow" role="presentation">
		                	<img src="<?php bloginfo('template_url')?>/img/services/sites/logo.png" alt="Декоративный элемент - логотип" id="sites-logo">
		                	<img src="<?php bloginfo('template_url')?>/img/services/sites/menu.png" alt="Декоративный элемент - меню" id="sites-menu">
		                	<img src="<?php bloginfo('template_url')?>/img/services/sites/monitor.png" alt="Декоративный элемент - монитор" id="sites-monitor">
		                	<img src="<?php bloginfo('template_url')?>/img/services/sites/sofora.png" alt="Декоративный элемент - Софора" id="sites-sofora">
		                </div>
		                <i class="service__i">01</i>
		            </div>
		        </div>
		        <div class="slider__item slider__item--next">
		            <div class="service">
		                <h3 class="service__title"><a href="<?= get_site_url(null,'/smm') ?>">SMM</a></h3>
		                <p class="service__text">Ведем бизнес-аккаунты, настраиваем таргетинговую рекламу, работаем на <span class="stroke stroke--pink">узнаваемость вашего бренда</span></p>
		                <div class="service__preview" rel="nofollow" role="presentation">
		                	<span id="smm-eggs" class="service__preview-img">
		                		<picture>
		                			<source type="image/webp" srcset="<?php bloginfo('template_url')?>/img/services/smm/eggs.webp">
		                			<img src="<?php bloginfo('template_url')?>/img/services/smm/eggs.png" alt="Декоративный элемент - окно instagram">
		                		</picture>
		                	</span>
		                	<span id="smm-eggs-sm" class="service__preview-img">
		                		<picture>
		                			<source type="image/webp" srcset="<?php bloginfo('template_url')?>/img/services/smm/eggs-likes.webp">
		                			<img src="<?php bloginfo('template_url')?>/img/services/smm/eggs-likes.png" alt="Декоративный элемент - окно instagram">
		                		</picture>
		                	</span>
		                </div>
		                <i class="service__i">02</i>
		            </div>
		        </div>
		        <div class="slider__item">
		            <div class="service">
		                <h3 class="service__title"><a href="<?= get_site_url(null,'/promotion') ?>">Контекстная реклама</a></h3>
		                <p class="service__text">Разрабатываем рекламные кампании <span class="stroke stroke--pink">для привлечения клиентов</span></p>
		                <div class="service__preview" rel="nofollow" role="presentation">
		                	<img src="<?php bloginfo('template_url')?>/img/services/context/helmet.png" alt="Декоративный элемент - шлем" id="context-helmet">
		                	<img src="<?php bloginfo('template_url')?>/img/services/context/helmet_shandow.png" alt="Декоративный элемент - тень шлема" id="context-shadow">
		                	<svg id="context-hint" x="0px" y="0px" viewBox="0 0 185 85" width="185" height="85">
			                	<g>
			                		<polygon class="context-hint__line" points="127.7,56.1 0.8,56.1 0.8,54.1 127.3,54.1 182.8,28.7 183.7,30.5 	"/>
			                	</g>
			                	<g>
			                		<path class="context-hint__text" d="M1.1,0h4.3v6.3L10.8,0h5.1L10,6.7l6.1,8.8h-5.2L7,9.8l-1.6,1.8v4H1.1V0z"/>
			                		<path class="context-hint__text" d="M17.2,14.7l1.7-3.1c0.6,0.4,1.3,0.5,1.8,0.5c0.4,0,0.9-0.1,1.4-0.7L15.9,0h4.8l3.5,7.3L27.6,0h4.7l-6.1,11.8
			                			c-1.4,2.8-2.9,3.9-5.3,3.9C19.5,15.7,18.3,15.3,17.2,14.7z"/>
			                		<path class="context-hint__text" d="M33.6,0h13.9v15.5h-4.3V3.8h-5.3v11.8h-4.3V0z"/>
			                		<path class="context-hint__text" d="M50.3,0h4.3v8.7l6-8.7h4v15.5h-4.3V6.8l-6,8.7h-4V0z"/>
			                		<path class="context-hint__text" d="M71.1,3.8h-4.7V0H80v3.8h-4.7v11.8h-4.3V3.8z"/>
			                		<path class="context-hint__text" d="M81.9,0h4.3v4.9h2.4c3.7,0,6.5,1.8,6.5,5.3c0,3.3-2.4,5.4-6.2,5.4h-6.9V0z M88.5,11.9c1.4,0,2.3-0.6,2.3-1.9
			                			c0-1.1-0.8-1.8-2.2-1.8h-2.3v3.7H88.5z"/>
			                		<path class="context-hint__text" d="M1.1,26.6h4.3v11.8h4.4V26.6h4.3v11.8h4.4V26.6h4.3v15.5H1.1V26.6z"/>
			                		<path class="context-hint__text" d="M23.9,42l0.3-3.3c0.2,0,0.8,0.1,1,0.1c1.2,0,2.4-0.6,2.4-10v-2.2h11.9v15.5h-4.3V30.4h-3.6V31
			                			c0,9.5-2.1,11.4-5.1,11.4C25.4,42.3,24.2,42.1,23.9,42z"/>
			                		<path class="context-hint__text" d="M42.2,26.6h12.5v3.7h-8.2v2.4h7.4V36h-7.4v2.5h8.3v3.7H42.2V26.6z"/>
			                		<path class="context-hint__text" d="M57,26.6h4.5l3.7,6l3.7-6h4.5v15.5h-4.3v-8.9l-4,6.1h-0.1l-3.9-6v8.9H57V26.6z"/>
			                	</g>
			                	<g>
			                		<path class="context-hint__info" d="M0,82l1.4-1.3c1.3,1.6,3,2.6,5.1,2.6c2.1,0,3.8-1.3,3.8-3.4c0-2.2-2-3.4-4.9-3.4H4.3l-0.4-1.2l5.5-6.2H0.9
			                			v-1.8h11.2v1.4l-5.5,6.1c3,0.3,5.8,1.7,5.8,5c0,3.1-2.6,5.3-5.8,5.3C3.6,85.1,1.4,83.8,0,82z"/>
			                		<path class="context-hint__info" d="M15.4,82.3l1.3-1.4c1.5,1.5,3.2,2.4,5,2.4c2.5,0,4.2-1.6,4.2-3.9c0-2.2-1.8-3.7-4.3-3.7c-1.5,0-2.6,0.4-3.7,1
			                			l-1.3-0.9l0.5-8.5h10.1v1.8h-8.3l-0.4,5.6c1-0.4,2-0.8,3.4-0.8c3.4,0,6,2,6,5.4c0,3.4-2.6,5.7-6.2,5.7
			                			C19.1,85.1,16.9,83.9,15.4,82.3z"/>
			                		<path class="context-hint__info" d="M37.6,79.5v-2.1h-2.4v-1.6h2.4v-9.4h5.2c5.4,0,6.3,3.4,6.3,5.5c0,2.7-1.7,5.5-6.3,5.5h-3.3v2.1h6.4v1.6h-6.4
			                			v3.7h-1.8v-3.7h-2.4v-1.6H37.6z M39.4,75.8h3.3c3.3,0,4.5-1.9,4.5-3.9c0-2-1.2-3.9-4.5-3.9h-3.3V75.8z"/>
			                		<path class="context-hint__info" d="M55.7,82.3l1.2-1.4c1.8,1.7,3.6,2.5,6.1,2.5c2.1,0,4.1-1.3,4.1-3.4c0-2.3-2-3.2-4.7-3.2h-1.9v-1.6h1.9
			                			c2.5,0,4.3-1.2,4.3-3.3c0-1.8-1.6-3.1-3.9-3.1c-2,0-3.6,0.6-5.1,2l-1.1-1.4c1.7-1.5,3.6-2.3,6.3-2.3c3.5,0,5.9,2,5.9,4.7
			                			c0,2.3-1.6,3.5-3.2,4.1c2.1,0.6,3.7,2,3.7,4.3c0,2.8-2.5,5-6.1,5C60,85.1,57.8,84.2,55.7,82.3z"/>
			                		<path class="context-hint__info" d="M79.1,67.2h1.8l8,17.6h-2.1l-2-4.6h-9.5l-2.1,4.6h-2L79.1,67.2z M83.9,78.4l-4-8.9l-4,8.9H83.9z"/>
			                		<path class="context-hint__info" d="M99.8,67.3h2v10.4l10-10.4h2.5l-7.5,7.6l7.8,9.8h-2.5l-6.7-8.5l-3.7,3.8v4.7h-2V67.3z"/>
			                		<path class="context-hint__info" d="M115.2,84.6l0.4-1.6c0.3,0.1,1,0.3,1.5,0.3c1.3,0,3.6-0.8,3.6-12.7v-3.2H132v17.5h-2V69.1h-7.4V71
			                			c0,12.3-2.5,14-5.2,14C116.7,85,115.6,84.8,115.2,84.6z"/>
			                		<path class="context-hint__info" d="M137,67.3h2v14.5l10.4-14.5h1.9v17.5h-1.9V70.3l-10.4,14.5H137V67.3z"/>
			                		<path class="context-hint__info" d="M156.2,67.3h2v10.4l10-10.4h2.5l-7.5,7.6l7.8,9.8h-2.5l-6.7-8.5l-3.7,3.8v4.7h-2V67.3z"/>
			                	</g>
		                	</svg>
		                </div>
		                <i class="service__i">03</i>
		            </div>
		        </div>
		        <div class="slider__item">
		            <div class="service">
		                <h3 class="service__title"><a href="<?= get_site_url(null,'/design') ?>">Брендинг</a></h3>
		                <p class="service__text">Разрабатываем фирменные стили, логотипы, носители, <span class="stroke stroke--pink">выделяющие вас среди конкурентов</span></p>
		                <div class="service__preview" rel="nofollow" role="presentation">
		                	<span id="branding-cup" class="service__preview-img">
		                		<picture>
		                			<source type="image/webp" srcset="<?php bloginfo('template_url')?>/img/services/branding/mug.webp">
		                			<img src="<?php bloginfo('template_url')?>/img/services/branding/mug.png" alt="Декоративный элемент - кружка" >
		                		</picture>
		                	</span>
		                	<span id="branding-cup-shadow" class="service__preview-img">
		                		<picture>
		                			<source type="image/webp" srcset="<?php bloginfo('template_url')?>/img/services/branding/mug_shandow.webp">
		                			<img src="<?php bloginfo('template_url')?>/img/services/branding/mug_shandow.png" alt="Декоративный элемент - тень кружки" >
		                		</picture>
		                	</span>
		                	<span id="branding-badge" class="service__preview-img">
		                		<picture>
		                			<source type="image/webp" srcset="<?php bloginfo('template_url')?>/img/services/branding/badge.webp">
		                			<img src="<?php bloginfo('template_url')?>/img/services/branding/badge.png" alt="Декоративный элемент - значок">
		                		</picture>
		                	</span>
		                	<span id="branding-badge-shadow" class="service__preview-img">
		                		<picture>
		                			<source type="image/webp" srcset="<?php bloginfo('template_url')?>/img/services/branding/badge_shandow.webp">
		                			<img src="<?php bloginfo('template_url')?>/img/services/branding/badge_shandow.png" alt="Декоративный элемент - тень значка">
		                		</picture>
		                	</span>
		                	<span id="branding-logo" class="service__preview-img">
		                		<picture>
		                			<source type="image/webp" srcset="<?php bloginfo('template_url')?>/img/services/branding/logo_text.webp">
		                			<img src="<?php bloginfo('template_url')?>/img/services/branding/logo_text.png" alt="Декоративный элемент - Логотип">
		                		</picture>
		                	</span>
		                </div>
		                <i class="service__i">04</i>
		            </div>	
		        </div>
		        <div class="slider__item slider__item--placeholder">
		        	<div class="service service--placeholder">
		        		<a href="#ask" class="btn btn--b" data-toggle="modal">Оставить заявку</a>
		        	</div>
		        </div>
    		</div>
    	</div>
    	<div class="slider__arrows" rel="nofollow">
    		<span class="slider__arrow slider__arrow--dark slider__arrow--left" role="button"></span>
    		<span class="slider__arrow slider__arrow--dark slider__arrow--right" role="button"></span>
    	</div>
    </div>
</section>