<section class="section partners <?php echo $partners['css_class']; ?>">
    <div class="container">
        <h2 class="section__title <?php echo 'section__title--'.$partners['title_color']; ?> <?php echo $partners['visible_title'] ? '' : 'invisible'; ?>"><?php echo $partners['title']; ?></h2>
    </div>

    <?php if($partners['text']): ?>
    <div class="container container--sm">
        <p class="text-center">Мы сотрудничаем с компаниями разной величины, которые помогают нам внашей работе, или мы помогаем им:</p>
    </div>
    <?php endif; ?>

    <div class="container">
        <div class="partners__list">
            <div class="partners__item">
                <img src="<?php bloginfo('template_url')?>/img/general/top.png" alt="">
            </div>
            <div class="partners__item">
                <img src="<?php bloginfo('template_url')?>/img/general/agency201.png" alt="">
            </div>
            <div class="partners__item">
                <img src="<?php bloginfo('template_url')?>/img/general/1c.png" alt="">
            </div>
            <div class="partners__item">
                <img src="<?php bloginfo('template_url')?>/img/general/sound.png" alt="">
            </div>
        </div>
    </div>
</section>