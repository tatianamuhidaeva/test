<?php get_header(); the_post(); ?>
<?php 
    # Выводит шапку сайта. (components/header)
    get_template_part('components/header/view');
?>

<section class="section about case">
    <div class="container">
        <h2 class="section__title section__title--black mb-4"><?php the_title(); ?></h2>
        <video style="max-width: 100%" autoplay buffered loop muted preload banner="<?php echo get_bloginfo('template_url').'/img/general/true_code.jpg'; ?>">
            <source src="<?php echo get_bloginfo('template_url').'/img/video/true_code.mp4'; ?>" type="video/mp4">
            <source src="<?php echo get_bloginfo('template_url').'/img/video/true_code.webm'; ?>" type="video/webm">
            <img src="<?php echo get_bloginfo('template_url').'/img/general/true_code.jpg'; ?>" alt="Команда веб-студии Верный Код">     
        </video>
    </div>

    <div class="container container--sm">
       <div class="case__text-block">
           <p>Студия Верный код была основана в 2013 году. Мы помогаем бизнесу найти своих клиентов в интернете: создаем для них сайты, настраиваем рекламу, продвигаем в социальных сетях.</p>
           <p>Над проектами в нашей студии работают не люди по отдельности, а целая команда специалистов: проектный менеджер, дизайнер, верстальщик, программист, маркетолог, специалист по контекстной рекламе, СММ специалист.</p>
       </div>
    </div>

    <div class="container">
        <div class="case__text-block">
            <h2 class="case__title case__title--center">Наша статистика</h2>
            <div class="out-stat mt-8">
                <div class="out-stat__item">
                    <div class="our-stat__number">5</div>
                    <strong class="our-stat__title">лет на digital-рынке</strong>
                </div>
                <div class="out-stat__item">
                    <div class="our-stat__number">6</div>
                    <strong class="our-stat__title">специалистов работают над одним проектом</strong>
                </div>
                <div class="out-stat__item">
                    <div class="our-stat__number">8</div>
                    <strong class="our-stat__title">проектов одновременно в работе</strong>
                </div>
            </div>
        </div>
    </div>

    <div class="container container--sm">
        <div class="case__text-block mb-13">
            <p class="text-center">Нашим клиентам мы предлагаем полный перечень digital-услуг отразработки до продвижения и поддержки проектов. На каждом проекте обязательно происходят консультации, посвященные будущему проекту и тому, как сделать его еще лучше.</p>
        </div>
    </div>

    <div class="container">
        <h2 class="case__title case__title--center invisible">Партнеры</h2>
        <div class="case__text-block clearfix">
            <img src="<?php bloginfo('template_url')?>/img/general/top-color.png" alt="" style="float: right;" class="mr-8--tablet ml-20--notebook mt-2" rel="nofollow" role="presentation">
            <p class="pr-8--tablet pl-8--tablet">Верный код сотрудничает с различными компаниями, которым мы можем быть полезны, или они могут быть полезны нашим клиентам. Так, например, у нас есть отличная производственная компания «Тор», которая занимается изготовлением вывесок, баннеров, выставочных систем. Мы работаем с ними с самого основания Верного кода и с уверенностью можем рекомендовать их нашим клиентам.</p>
        </div>
    </div>

    <?php
        # выводит секцию с партнерами. (components/partners)
        partners(array(
            'css_class' => 'partners--bg-white pb-9',
            'text' => true
        ));
    ?>

    <div class="container">
        <div class="case__text-block mt-9">
            <p class="pr-8--tablet pl-8--tablet">Мы всегда рады новым специалистам в нашей команде и регулярно<br>проводим набор в штат или на стажировку:</p>
        </div>
    </div>

    <?php 
        # выводит Вакансии
        get_template_part('components/opening/opening'); 
    ?>
</section>

<?php
    # выводит секцию с формой обратной связи. (components/bid)
    bid();
?>

<footer class="case-footer pb-10">
    <nav class="case-footer__nav case-footer__nav--around">
        <a href="javascript:history.back()" class="btn btn--back btn--white case-footer__back">Назад</a>
    </nav>
</footer>
<?php get_footer(); ?>   