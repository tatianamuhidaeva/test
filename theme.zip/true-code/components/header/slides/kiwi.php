<div class="case-slide">
	<div class="invisible">
		<h3>Kiwi Immigration</h3>
	</div>

	<div class="case-slide__animate kiwi-case" rel="nofollow" role="presentation">
		<img src="<?php bloginfo('template_url')?>/img/case-slider/kiwi_1.png" alt="Часть составного изображения" class="kiwi-case__img kiwi-case__img--layer1">      
		<img src="<?php bloginfo('template_url')?>/img/case-slider/kiwi_2.png" alt="Часть составного изображения" class="kiwi-case__img kiwi-case__img--layer2">      
		<img src="<?php bloginfo('template_url')?>/img/case-slider/kiwi_3.png" alt="Часть составного изображения" class="kiwi-case__img kiwi-case__img--layer3"> 
		<img src="<?php bloginfo('template_url')?>/img/case-slider/kiwi_4.png" alt="Часть составного изображения" class="kiwi-case__img kiwi-case__img--layer4"> 
	</div>

	<div class="case-slide__preview" rel="nofollow" role="presentation">
		<picture>
			<source type="image/webp" srcset="<?php bloginfo('template_url')?>/img/case-slider/bundle-kiwi-1x.webp 1x, <?php bloginfo('template_url')?>/img/case-slider/bundle-kiwi-2x.webp 2x">
			<img srcset="<?php bloginfo('template_url')?>/img/case-slider/bundle-kiwi-1x.png 1x, <?php bloginfo('template_url')?>/img/case-slider/bundle-kiwi-2x.png 2x" src="<?php bloginfo('template_url')?>/img/case-slider/bundle-kiwi-2x.png" alt="Превью кейса">
		</picture>
	</div>
	<a href="<?php echo get_site_url().'/case/kiwi-immigration/'; ?>" class="btn btn--a case-slide__btn">Посмотри кейс</a>
</div>