<div class="modal-layout" id="ask" role="dialog">
	<div class="modal modal--auto">
		<div class="modal__close">✖</div>
		<div class="modal__header text-center">Оставить заявку</div>
		<div class="modal__body">
			<form class="bid__form envelope">
			    <div class="envelope__body">
			        <div class="envelope__fieldset">
			            <label for="name-recall" class="envelope__label">Имя</label>
			            <input type="text" id="name-recall" name="name" class="envelope__form-control" required>
			        </div>
			        <div class="envelope__fieldset">
			            <label for="email-recall" class="envelope__label">Email</label>
			            <input type="email" id="email-recall" name="email" class="envelope__form-control" required>
			        </div>
			        <div class="envelope__fieldset">
			            <label for="phone-recall" class="envelope__label">Телефон</label>
			            <input type="text" id="phone-recall" name="phone" class="envelope__form-control" data-mask="+7(000)000-00-00" required>
			        </div>
			        <div class="envelope__fieldset">
			            <label for="services-recall" class="envelope__label">Какие услуги вас интересуют?</label>
			            <select name="services" id="services-recall" class="envelope__select-control">
			                <option value="Сайты">Сайты</option>
			                <option value="Контекстная реклама">Контекстная реклама</option>
			                <option value="Фирменный стиль">Фирменный стиль</option>
			                <option value="SMM">SMM</option>
			            </select>
			        </div>
			        <div class="envelope__fieldset">
			            <label for="message-recall" class="envelope__label envelope__label--for-textarea">Вопрос</label>
			            <textarea name="message" id="message-recall" rows="4" class="envelope__textarea-control"></textarea>
			        </div>
			    </div>
			    <div class="envelope__footer text-center">
			    	<div class="envelope__fieldset">
			    	    <label for="terms-recall" class="envelope__label politica">
			    	    	<input type="checkbox" name="terms" id="terms-recall" class="invisible" value="Я принимаю политику конфиденциальности">
			    	    	<span class="envelope__checkbox-control envelope__checkbox-control--pink"></span>
			    	    	Я принимаю политику конфиденциальности
			    	    </label>
			    	</div>
			    	<input type="hidden" name="subject" value="Вопрос на сайте">
			    	<button type="submit" class="btn btn--a envelope__btn disabled" onclick="ym(38838170, 'reachGoal', 'zayavka'); return true;">Отправить</button>
			    </div>
			</form>
		</div>
	</div>
</div>