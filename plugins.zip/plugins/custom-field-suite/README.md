# Custom Field Suite

[![](https://img.shields.io/wordpress/plugin/dt/custom-field-suite.svg)](https://wordpress.org/plugins/custom-field-suite/)
[![](https://img.shields.io/wordpress/v/custom-field-suite.svg)](https://wordpress.org/plugins/custom-field-suite/)
[![](https://img.shields.io/wordpress/plugin/r/custom-field-suite.svg)](https://wordpress.org/plugins/custom-field-suite/)

Please see the official [WordPress.org project page](https://wordpress.org/plugins/custom-field-suite/)