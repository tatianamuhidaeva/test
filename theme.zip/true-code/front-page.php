<?php get_header(); ?>
<?php 
    # Выводит шапку сайта. (components/header)
    get_template_part('components/header/view');

    # Выводит промо сайта. (components/digital)
    get_template_part('components/digital/view');

    # Выводит слайдер с услугами. (components/services)
    services();

    # выводит плитки портфолио. (components/portfolio)
    portfolio(array(
        'title' => 'Наши работы',
        'title_color' => 'purple',
        'nav' => false
    ));

    # выводит секцию с формой обратной связи. (components/bid)
    bid(array(
        'visible_title' => true
    ));

    # выводит секцию с партнерами. (components/partners)
    partners(array(
        'visible_title' => true
    ));

    # выводит секцию с контактами. (components/contacts)
    contacts();
?>
<?php get_footer(); ?>      