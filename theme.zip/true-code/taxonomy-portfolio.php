<?php 
    // t-code/portfolio/...
?>
<?php get_header(); ?>
<?php
    # Выводит шапку сайта. (components/header)
    page_header(array(
        'title' => get_the_title(),
        'css_class' => 'header--b page__header',
        'hero' => false,
        'case' => false
    ));

    # выводит плитки портфолио. (components/portfolio)
    portfolio(array(
        'title' => 'Портфолио',
        'title_color' => 'black',
        'nav' => true,
        'show_portfolio_link' => false
    ));

    # выводит секцию с формой обратной связи. (components/feedback/bid)
    bid(array(
        'visible_title' => true
    ));
?>
<?php get_footer(); ?> 