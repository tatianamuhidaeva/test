<?php
    $format = is_home() ? get_option('page_for_posts') : null;
    page_header(array(
        'title' => get_field('header_title', $format) ? get_field('header_title', $format) : get_the_title(),
        'css_class' => 'header--'.get_field('header_scheme', $format).' page__header',
        'hero' => get_field('header_hero', $format)['is_active']
            ? array(
                'title' => get_field('header_hero', $format)['title'] ? get_field('header_hero', $format)['title'] : get_the_title(),
                'image' => get_field('header_hero', $format)['img'] ? get_field('header_hero', $format)['img'] : get_the_post_thumbnail_url($post, 'hero'),
                'video' => array(
                    get_field('header_hero', $format)['video_webm']
                    ? array(
                        'src' => get_field('header_hero', $format)['video_webm'],
                        'type' => 'video/webm'
                    ) : '',
                    get_field('header_hero', $format)['video_mp4']
                    ? array(
                        'src' => get_field('header_hero', $format)['video_mp4'],
                        'type' => 'video/mp4'
                    ) : ''
                )
            ) : false,
        'navbar' => array(
            'css_class' => get_field('header_hero', $format)['is_active'] ? 'header__navbar header__navbar--above' : 'header__navbar'
        ),
        // 'case' => get_field('header_case', $format)['is_active'] ? true : false,
        'case' => false,
    ));