<?php get_header(); the_post(); ?>
<?php 
    # Выводит шапку сайта. (components/header)
    page_header(array(
        'title' => get_the_title(),
        'css_class' => 'header--b page__header',
        'hero' => false,
        'case' => false
    )); 
?>
<section class="section blog">
    <div class="container">
        <div class="blog__layout">
            <main class="blog__main">
                <article class="post blog__article">
                    <h2><?php the_title(); ?></h2>
                    <?php the_content(); ?>
                </article>
                <nav class="blog__share">
                    <div class="share">
                        <strong class="share__title">Зашарить вакансию:</strong>
                        <a href="https://vk.com/share.php?url=<?php echo get_the_permalink(); ?>" target="_blank" class="share__link share__link--vk">ВК</a>
                        <a href="https://www.facebook.com/sharer/sharer.php?u=<?php echo get_the_permalink(); ?>" target="_blank" class="share__link share__link--fb">FB</a>
                        <a href="http://www.odnoklassniki.ru/dk?st.cmd=addShare&st.s=1&st._surl=<?php echo get_the_permalink(); ?>" target="_blank" class="share__link share__link--ok">OK</a>
                        <a href="http://twitter.com/share?url=<?php echo get_the_permalink(); ?>" target="_blank" class="share__link share__link--tw">ТВИТНУТЬ</a>
                    </div>
                </nav>
            </main>
            <aside class="blog__aside">
                <?php get_template_part('components/feedback/envelope','min'); ?>
            </aside>
        </div>
    </div>
</section>
<?php get_footer(); ?> 