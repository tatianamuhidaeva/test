<div class="loader" id="preloader">
	<img src="<?php bloginfo('template_url'); ?>/img/general/preloader.gif" alt="">
</div>
