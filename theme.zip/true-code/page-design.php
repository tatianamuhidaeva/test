<?php get_header(); the_post(); ?>
<?php 
    # Выводит шапку сайта. (components/header)
    get_template_part('components/header/view');
?>
<section class="case">
    <div class="container container--sm">
        <div class="case__description">
            <p><strong>Фирменный стиль</strong> – это не только лицо вашей компании и графическое обозначение вашего бизнеса, но еще и свод определенных правил, позволяющих эстетично использовать весь визуальный потенциал вашего стиля. Логотип, наружная реклама, пресс-волы, уникальные бейджи сотрудников, бланки писем, ручки, блокноты – все это должно быть органично связано между собой одной общей концепцией.</p>
            <p>Выходя в свет, вы заботитесь о своем внешнем виде. Выводя в свет свой бизнес, вы наверняка тоже думаете о том, что он должен выгодно выглядеть как на фоне конкурентов, так и в глазах клиентов.</p>
            <p>Вокруг нас огромное количество логотипов, символов, названий компаний. И наша задача – сделать внешний вид вашего бизнеса уникальным и запоминающимся.</p>
        </div>
    </div>
    <div class="container container--sm mt-6 mt-10--notebook">
       <div class="case__text-block clearfix mt-2 mt-4--tablet mb-4 mb-7--tablet">
            <h2 class="case__title">Этапы разработки фирменного стиля</h2>
            <p>Разработка фирменного стиля никогда не основывается только лишь на пожеланиях клиента и личных задумках дизайнера. Она опирается на исследование бизнеса, его конкурентов, индивидуальных особенностей услуг или товаров, основы типографики и дизайна, личных пожеланий заказчика.</p>
       </div>
    </div>
    
    <div class="slider case__slider">
        <div class="slider__container my-5 my-10--tablet">
            <?php get_template_part('components/case-slider/slider'); ?>
        </div>
    </div>

    <div class="container container--sm">
        <div class="case__text-block mt-2 mt-4--tablet mb-4 mb-7--tablet">
            <h2 class="case__title invisible">Правила использования элементов</h2>
            <p>Для того, чтобы вы могли в последующем самостоятельно использовать свой фирменный стиль, в брендбуке мы пропишем правила использования элементов, коды ваших фирменных цветов и используемые шрифты.</p>
        </div>
        <div class="case__text-block mt-2 mt-4--tablet mb-4 mb-7--tablet">
            <p>Правила использования элементов – это особые указания по использованию фирменного стиля, которые необходимо соблюдать для эстетичного отображения логотипа. Например, охранное поле логотипа необходимо для того, чтобы куда бы не поместили логотип, он выглядел адекватно и эстетично, не затрагивая сторонние элементы. </p>
        </div>
    </div>

    <div class="common-block common-block--sofora" rel="nofollow" role="presentation">
        <div class="container">
            <img src="<?php bloginfo('template_url')?>/img/general/colors.png" alt="" id="colors" class="animated">
            <img src="<?php bloginfo('template_url')?>/img/general/balloon.png" alt="" id="balloon" class="animated">
            <img src="<?php bloginfo('template_url')?>/img/general/visitka.png" alt="" id="visitka" class="animated">
            <img src="<?php bloginfo('template_url')?>/img/general/sofora.png" alt="" id="sofora" class="animated">
            <img src="<?php bloginfo('template_url')?>/img/general/note.png" alt="" id="note" class="animated">
        </div>
    </div>

    <div class="container container--sm">
        <div class="case__text-block">
            <h2 class="case__title invisible">Итог</h2>
            <p>Список необходимой канцелярии и носителей без проблем можно корректировать и использовать на разнообразных вещах: от календариков до билбордов. В конце разработки фирменного стиля мы отдаем все исходные материалы, которые можно вставлять на различные источники самостоятельно. </p>
        </div>
    </div>

    <div class="case-common case-common--nadnami">
        <div class="case-common__inner">
            <img src="<?php bloginfo('template_url')?>/img/general/bro.png" alt="" class="case-common__img case-common__img--nadnami-1" rel="nofollow" role="presentation">
            <div class="case-common__blank case-common__blank--nadnami">
                <img src="<?php bloginfo('template_url')?>/img/general/nadnami-logo.png" alt="" class="case-common__logo" rel="nofollow" role="presentation">
                <div class="case-common__text">
                    <p>Например, как мы это сделали<br>для компании<br>«НАДНАМИ»</p>
                    <a href="<?php echo get_site_url().'/case/nadnami'; ?>" class="case-common__link">Посмотреть кейс</a>
                </div>
            </div>
            <img src="<?php bloginfo('template_url')?>/img/general/star.png" alt="" class="case-common__img case-common__img--nadnami-2" rel="nofollow" role="presentation">
        </div>
    </div>
</section>

<?php 
    # выводит секцию с формой обратной связи. (components/feedback/bid)
    bid(array(
        'visible_title' => false
    ));
?>

<footer class="case-footer pb-10">
    <nav class="case-footer__nav case-footer__nav--around">
        <a href="<?php echo get_site_url().'/sites'; ?>" class="btn btn--back btn--white case-footer__back">Создание сайтов</a>
        <a href="<?php echo get_site_url().'/promotion'; ?>" class="btn btn--next btn--white case-footer__next">Контекстная реклама</a>
    </nav>
</footer>
<?php get_footer(); ?>