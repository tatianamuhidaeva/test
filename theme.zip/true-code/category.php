<?php get_header(); ?>
<?php
    # Выводит шапку сайта. (components/header)
    page_header(array(
        'title' => get_the_title(),
        'css_class' => 'header--b page__header',
        'hero' => false,
        'case' => false
    )); 
?>
<section class="section blog">
    <div class="container">
        <div class="blog__layout">
            <main class="blog__main">
                <?php 
                    $queried_object = get_queried_object();
                    $query = new WP_Query(array(
                        'post_type' => 'post',
                        'cat' => $queried_object->term_id,
                        'posts_per_page' => 3,
                        'order' => 'DESC',
                        'orderby' => 'date'
                    ));
                    if ( $query->have_posts() ): 
                        while ($query->have_posts()): $query->the_post();
                            echo blog_card();  
                        endwhile;
                ?>

                <div id="postLoaderContent"></div>

                <?php if($query->max_num_pages > 1): ?>
                <nav class="blog__nav">
                    <a id="postLoaderToggler" class="btn btn--c blog__more" data-number="3" data-post-type="post">Еще записи</a>
                </nav>
                <?php endif; ?>

                <?php 
                    endif; 
                ?>
            </main>
            <aside class="blog__aside">
                <?php get_template_part('components/feedback/envelope','min'); ?>
            </aside>
        </div>
    </div>
</section>
<?php get_footer(); ?> 