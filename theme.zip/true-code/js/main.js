var caseSlider = {
  slides: $('.case-slider__item'),
  offset: {},
  bp: {
    mobile: 676,
    mobileUp: 577,
    tablet: 768,
    tabletUp: 769,
    notebook: 992,
    notebookUp: 993,
    laptop: 1200
  },
  setOffset: function (side) {
    this.offset.lg += 60 * side;
    this.offset.sm += 100 * side;
    this.resetOffset();
  },
  resetOffset: function () {
    if ($(window).width() > this.bp.laptop) {
      this.offset.current = this.offset.lg;
    } else {
      this.offset.current = this.offset.sm;
    }
  },
  getCurrentSlide: function () {
    return this.slides.filter('.case-slider__item--current');
  },
  getCurrentIndex: function () {
    return this.currentSlide.index();
  },
  countTrack: function () {
    this.trackWidth = 0;

    for (var i = 0; i < this.slides.length; i++) {
      this.trackWidth += $(this.slides[i]).outerWidth();
    }

    $('.case-slider__track').outerWidth(this.trackWidth);
  },
  addClass: function () {
    $(this.slides[this.currentIndex - 1]).addClass('case-slider__item--prev');
    $(this.slides[this.currentIndex]).addClass('case-slider__item--current');
    $(this.slides[this.currentIndex + 1]).addClass('case-slider__item--next');
  },
  removeClass: function () {
    $(this.slides[this.currentIndex - 1]).removeClass('case-slider__item--prev');
    $(this.slides[this.currentIndex]).removeClass('case-slider__item--current');
    $(this.slides[this.currentIndex + 1]).removeClass('case-slider__item--next');
  },
  goToSlide: function (n) {
    this.removeClass();
    this.currentIndex = (n + this.slides.length) % this.slides.length;
    this.addClass();
  },
  moveTrack: function (offset) {
    $('.case-slider__track').css({
      'transform': 'translateX(' + offset + 'vw)'
    });
  },
  swipeLeft: function () {
    if ($('.case-slider__item').is('.case-slider__item--next')) {
      this.goToSlide(this.currentIndex + 1);
      this.setOffset(-1);
      this.moveTrack(this.offset.current);
    }
  },
  swipeRight: function () {
    if ($('.case-slider__item').is('.case-slider__item--prev')) {
      this.goToSlide(this.currentIndex - 1);
      this.setOffset(1);
      this.moveTrack(this.offset.current);
    }
  },
  init: function () {
    this.currentSlide = this.getCurrentSlide();
    this.currentIndex = this.getCurrentIndex();
    this.offset.lg = -100;
    this.offset.sm = -200;
    this.resetOffset();
    this.countTrack();
  }
};
caseSlider.init();
$(window).resize(function () {
  caseSlider.countTrack();
  caseSlider.resetOffset();
});

function toggleArrows() {
  if ($('.case-slider__track').find('.case-slider__item').is('.case-slider__item--next:not(.case-slider__placeholder)')) {
    $('.case-slider__arrow--right').removeClass('case-slider__arrow--disabled');
  } else {
    $('.case-slider__arrow--right').addClass('case-slider__arrow--disabled');
  }

  if ($('.case-slider__track').find('.case-slider__item').is('.case-slider__item--prev:not(.case-slider__placeholder)')) {
    $('.case-slider__arrow--left').removeClass('case-slider__arrow--disabled');
  } else {
    $('.case-slider__arrow--left').addClass('case-slider__arrow--disabled');
  }
}

$('.case-slider__container').hammer().bind("swipeleft", function (e) {
  if ($('.case-slider__track').find('.case-slider__item').is('.case-slider__item--next:not(.case-slider__placeholder)')) {
    caseSlider.swipeLeft();
    toggleArrows();
  }
});
$('.case-slider__container').hammer().bind("swiperight", function (e) {
  if ($('.case-slider__track').find('.case-slider__item').is('.case-slider__item--prev:not(.case-slider__placeholder)')) {
    caseSlider.swipeRight();
    toggleArrows();
  }
});
$('body').on('click', '.case-slider__arrow--left, .case-slider__item--prev:not(.case-slider__placeholder)', function () {
  caseSlider.swipeRight();
  toggleArrows();
});
$('body').on('click', '.case-slider__arrow--right, .case-slider__item--next:not(.case-slider__placeholder)', function () {
  caseSlider.swipeLeft();
  toggleArrows();
});
$(".promo-text__word").first().find(".promo-text__letter").last().on("animationend webkitAnimationEnd oAnimationEnd MSAnimationEnd", function () {
  if ($(this).closest(".promo-text__word").hasClass("animate")) {
    $(".promo-text__word--right").addClass("animate");
  }
});
$(".promo-text__word--right").find(".promo-text__letter").last().on("animationend webkitAnimationEnd oAnimationEnd MSAnimationEnd", function () {
  if ($(this).closest(".promo-text__word").hasClass("animate")) {
    $(".promo-text__word").removeClass("animate");
    $(".promo-text__letter").addClass("is-visible");
    $(".promo-text__rand").first().addClass("animate");
  }
});
$(".promo-text__rand").first().on("animationend webkitAnimationEnd oAnimationEnd MSAnimationEnd", function () {
  if ($(this).hasClass("animate")) {
    $(".promo-text__rand").removeClass("animate");
    $(".promo-text__rand").first().addClass("is-visible");
    $(".promo-text__slash").addClass("animate");
  }
});
$(".promo-text__slash").last().one("animationend webkitAnimationEnd oAnimationEnd MSAnimationEnd", function () {
  $(".promo-text__slash").removeClass("animate");
  $(".promo-text__slash").addClass("is-visible");
});
$(".promo-text__rand").on("animationend webkitAnimationEnd oAnimationEnd MSAnimationEnd", function () {
  $(this).removeClass("is-visible");

  if ($(this).next().length) {
    $(this).next().addClass("is-visible");
  } else {
    $(".promo-text__word").addClass("flash");
  }
});
$(".promo-text__word").find(".promo-text__letter").last().on("animationend webkitAnimationEnd oAnimationEnd MSAnimationEnd", function () {
  $(".promo-text__word").removeClass("flash");
  $(".promo-text__rand").first().addClass("is-visible");
});
$('.envelope__select-control').styler();
$('body').on('submit', 'form.bid__form', function (e) {
  e.preventDefault();

  if ($('[name=terms]').is(':checked') && !$(this).find('[type=submit]').hasClass('disabled')) {
    var order = $(this);
    var form = $(this).serializeArray();
    $.post(myajax.url, {
      form: form,
      action: 'bid_form'
    }, function (data) {
      for (var i = 0; i < $('form.bid__form').length; i++) {
        $('form.bid__form')[i].reset();
      }

      $('.alert').removeClass('alert--in');
      $('.alert__body').html('Спасибо!<br>Ваше сообщение отправлено');
      $('.alert').addClass('alert--in');
      setTimeout(function () {
        $('.alert').removeClass('alert--in');
      }, 10000);
    });
  } else {
    $('.alert__body').html('Вам необходимо согласиться с политикой конфиденциальности');
    $('.alert').addClass('alert--in');
    setTimeout(function () {
      $('.alert').removeClass('alert--in');
    }, 10000);
  }
});
$('.header__nav-trigger').on('click', function () {
  $(this).toggleClass('main-nav__trigger--close');
  $('.header__menu').toggleClass('site-menu--opened');
});
$('[data-toggle=modal]').on('click', function () {
  $('body').css('overflow', 'hidden');
  var target = $(this).attr('href');
  $(target).addClass('modal-layout--show');
});
$('.modal__close').on('click', function () {
  var target = $(this).closest('.modal-layout');
  $(target).removeClass('modal-layout--show');
  $('body').css('overflow', 'visible');
});
$('.modal-layout').on('click', function (e) {
  if ($(e.target).is('.modal-layout')) {
    $(this).removeClass('modal-layout--show');
    $('body').css('overflow', 'visible');
  }
});
$('.alert__close').on('click', function () {
  var target = $(this).closest('.alert');
  $(target).removeClass('alert--in');
});
$('[name=terms]').on('click', function () {
  if ($(this).is(':checked')) {
    $(this).closest('form').find('[type=submit]').removeClass('disabled');
  } else {
    $(this).closest('form').find('[type=submit]').addClass('disabled');
  }
});
$('.spoiler-open').on('click', function () {
  var target = $(this).attr('data-target');
  $(target).toggleClass('opening__item--open');
});
$('.opening__close').on('click', function () {
  $(window).scrollTop($('.opening').offset().top);
  $(this).closest('.opening__item').removeClass('opening__item--open');
});
$('.simple-slider__container').each(function (i, elem) {
  new Swiper(this, {
    spaceBetween: 30,
    pagination: {
      el: $(this).closest('.simple-slider').find('.swiper-pagination'),
      clickable: true
    }
  });
});
var slider = {
  slides: $('.slider__item'),
  offset: {},
  bp: {
    mobile: 676,
    mobileUp: 577,
    tablet: 768,
    tabletUp: 769,
    notebook: 992,
    notebookUp: 993,
    laptop: 1200
  },
  setOffset: function (side) {
    this.offset.lg += 735 * side;
    this.offset.sm += 100 * side;
    this.resetOffset();
  },
  resetOffset: function () {
    if ($(window).width() > this.bp.notebook) {
      this.offset.current = this.offset.lg;
    } else {
      this.offset.current = this.offset.sm;
    }
  },
  getCurrentSlide: function () {
    return this.slides.filter('.slider__item--current');
  },
  getCurrentIndex: function () {
    return this.currentSlide.index();
  },
  countTrack: function () {
    this.trackWidth = 0;

    for (var i = 0; i < this.slides.length; i++) {
      this.trackWidth += $(this.slides[i]).outerWidth();
    }

    $('.slider__track').outerWidth(this.trackWidth);
  },
  addClass: function () {
    $(this.slides[this.currentIndex - 1]).addClass('slider__item--prev');
    $(this.slides[this.currentIndex]).addClass('slider__item--current');
    $(this.slides[this.currentIndex + 1]).addClass('slider__item--next');
  },
  removeClass: function () {
    $(this.slides[this.currentIndex - 1]).removeClass('slider__item--prev');
    $(this.slides[this.currentIndex]).removeClass('slider__item--current');
    $(this.slides[this.currentIndex + 1]).removeClass('slider__item--next');
  },
  goToSlide: function (n) {
    this.removeClass();
    this.currentIndex = (n + this.slides.length) % this.slides.length;
    this.addClass();
  },
  moveTrack: function (offset) {
    if ($(window).width() > 1440) {
      $('.slider__track').css({
        'transform': 'translateX(' + offset + 'px) translateX(8vw)'
      });
    } else if ($(window).width() > this.bp.notebook) {
      $('.slider__track').css({
        'transform': 'translateX(' + offset + 'px) translateX(12vw)'
      });
    } else {
      $('.slider__track').css({
        'transform': 'translateX(calc(' + offset + 'vw))'
      });
    }
  },
  swipeLeft: function () {
    if ($('.slider__track').find('.slider__item').is('.slider__item--next')) {
      this.goToSlide(this.currentIndex + 1);
      this.setOffset(-1);
      this.moveTrack(this.offset.current);
    }
  },
  swipeRight: function () {
    if ($('.slider__track').find('.slider__item').is('.slider__item--prev')) {
      this.goToSlide(this.currentIndex - 1);
      this.setOffset(1);
      this.moveTrack(this.offset.current);
    }
  },
  init: function () {
    this.currentSlide = this.getCurrentSlide();
    this.currentIndex = this.getCurrentIndex();
    this.offset.lg = 0;
    this.offset.sm = 0;
    this.resetOffset();
    this.countTrack();
  }
};
slider.init();
$(window).resize(function () {
  slider.countTrack();
  caseSlider.resetOffset();
});

function toggleRight() {
  if ($('.slider__track').find('.slider__item').is('.slider__item--next:not(.slider__item--placeholder)')) {
    $('.slider__arrow--right').removeClass('slider__arrow--disabled');
  } else {
    $('.slider__arrow--right').addClass('slider__arrow--disabled');
  }
}

function toggleLeft() {
  if ($('.slider__track').find('.slider__item').is('.slider__item--prev:not(.slider__item--placeholder)')) {
    $('.slider__arrow--left').removeClass('slider__arrow--disabled');
  } else {
    $('.slider__arrow--left').addClass('slider__arrow--disabled');
  }
}

$('.slider__track').hammer().bind("swipeleft", function (e) {
  if ($('.slider__track').find('.slider__item').is('.slider__item--next:not(.slider__item--placeholder)')) {
    slider.swipeLeft();
    toggleRight();
    toggleLeft();
  }
});
$('.slider__track').hammer().bind("swiperight", function (e) {
  if ($('.slider__track').find('.slider__item').is('.slider__item--prev:not(.slider__item--placeholder)')) {
    slider.swipeRight();
    toggleRight();
    toggleLeft();
  }
});
$('body').on('click', '.slider__arrow--left, .slider__item--prev:not(.slider__item--placeholder)', function () {
  slider.swipeRight();
  toggleRight();
  toggleLeft();
});
$('body').on('click', '.slider__arrow--right, .slider__item--next:not(.slider__item--placeholder)', function () {
  slider.swipeLeft();
  toggleRight();
  toggleLeft();
});