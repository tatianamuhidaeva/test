<?php 
    $queried_object = get_queried_object();
    if(is_page()) {
        $query = new WP_Query(array(
            'post_type' => 'case',
            'posts_per_page' => $portfolio['posts_per_page'],
            'order' => 'DESC',
            'orderby' => 'date',
            'post_status' => 'publish'
        ));
    } else {
        $query = new WP_Query(array(
            'portfolio' => $queried_object->slug,
            'post_type' => 'case',
            'posts_per_page' => $portfolio['posts_per_page'],
            'order' => 'DESC',
            'orderby' => 'date',
            'post_status' => 'publish'
        ));
    }

    if($query->have_posts()): 
?>
    <section class="section portfolio">
        <div class="container portfolio__container">
            <h2 class="section__title <?php echo 'section__title--'.$portfolio['title_color']; ?> <?php echo $portfolio['visible_title'] ? '' : 'invisible'; ?>"><?php echo $portfolio['title']; ?></h2>
            
            <?php 
                # Рубрикатор портфолио
                if($portfolio['nav']): 
                    $args = array(
                      'type'         => 'case',
                      'orderby'      => 'name',
                      'order'        => 'ASC',
                      'hide_empty'   => true,
                      'hierarchical' => false,
                      'taxonomy'     => 'portfolio',
                    );
                    $categories = get_categories( $args );
                    if( $categories ):  
            ?>
                <nav class="portfolio__nav">
                    <?php
                        if(is_page()) {
                            echo '<a class="portfolio__nav-link active">Все</a>';
                        } else {
                            echo '<a href="'.get_taxonomy_archive_link('portfolio').'" class="portfolio__nav-link">Все</a>';
                        }

                        foreach( $categories as $cat ){
                            if($cat->term_id == $queried_object->term_id) {
                                echo '<a class="portfolio__nav-link active">'.$cat->name.'</a>';
                            } else {
                                echo '<a href="'.get_category_link($cat->term_id).'" class="portfolio__nav-link">'.$cat->name.'</a>';
                            }
                        }
                    ?>
                </nav>
            <?php 
                    endif;
                endif;
                # Конец рубрикатора
            ?>
            
            <div class="portfolio__grid" id="postLoaderContent">
                <?php while ($query->have_posts()): $query->the_post(); ?>
                    <div class="portfolio__item">
                        <?php echo case_card(); ?>
                    </div>
                <?php endwhile; ?>
            </div>

            <?php if($portfolio['show_portfolio_link']): ?>
                <div class="portfolio__btn">
                    <a href="<?php echo get_site_url().'/portfolio'; ?>" class="btn btn--b">Все проекты</a>
                </div>
            <?php elseif($query->max_num_pages > 1): ?>
                <div class="portfolio__btn">
                    <a id="postLoaderToggler" class="btn btn--b"  data-offset="<?= $portfolio['posts_per_page'] ?>" data-show="6" data-type="case" data-tax="portfolio" <?= is_tax() ? 'data-term="'.$queried_object->slug.'"' : '' ?> data-template="case">Показать еще</a>
                </div>
            <?php endif; ?>
        </div>
    </section>
<?php endif; ?>