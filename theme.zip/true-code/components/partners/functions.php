<?php
	function partners($args = array()) {
		
		$default_args = array(
			'css_class' => '',
			'title' => 'Наши партнеры',
			'visible_title' => false,
			'title_color' => 'purple', // Модификатор в css (black, white, purple)
			'text' => false
		);
		$args = array_replace_recursive($default_args, $args);

		set_query_var('partners', $args);
		get_template_part('components/partners/partners');
	}