<!-- <form class="envelope envelope-min">
    <svg class="envelope__header" viewBox="0 0 289 90" height="90">
        <polygon class="envelope__triangle" points="0,57 144.5,0 289,57"/>
        <rect class="envelope__back" x="0" y="57" width="100%" height="33"/>
        <rect class="envelope__letter" x="5%" y="70" width="90%" height="20"/>
    </svg>
    <div class="envelope-min__body">
        <div class="envelope-min__subscr">Подпишись<br>на нашу рассылку</div>
        <div class="envelope__fieldset mb-1">
            <label for="email" class="envelope__label">Email</label>
            <input type="email" id="email" name="email" class="envelope__form-control" required>
        </div>
    </div>
    <div class="envelope-min__btn">
        <button type="submit" class="btn btn--c">Окей</button>
    </div>
</form> -->

<?php echo do_shortcode('[mc4wp_form id="274"]'); ?>