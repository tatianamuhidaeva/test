<?php

	if (function_exists('add_theme_support')) {
		add_theme_support('menus');
		add_theme_support('post-thumbnails');
		add_theme_support('custom-logo');
		add_theme_support('widgets');

		add_image_size('case-thumb', 263, 463, true);
		add_image_size('post-thumb', 750, 240, true);
		add_image_size('hero', 1920, 550, true);
		add_image_size('next-thumb', 642, 243, true);
		add_image_size('last-project', 736, 459, true);
	}

	remove_action('wp_head', 'print_emoji_detection_script', 7);
	remove_action('wp_print_styles', 'print_emoji_styles');

	add_action( 'wp_head', 'head_seo_meta_tags' );
	function head_seo_meta_tags() {
		echo '<meta charset="utf-8">';
		echo '<meta http-equiv="x-ua-compatible" content="ie=edge">';
		echo '<meta name="viewport" content="width=device-width, initial-scale=1">';
		echo '<title>'.wp_title('-', false, 'right').'</title>';
		echo '<meta name="description" content="'.get_bloginfo('description').'" />';
		echo '<meta name="keywords" content="" />';
		wp_site_icon();
	}

	function async_scripts($url) {
	    if ( strpos( $url, '#asyncload') === false ) {
	        return $url;
	    }

	    elseif ( is_admin() ) {
	        return str_replace( '#asyncload', '', $url );
	    }

	    else {
			return str_replace( '#asyncload', '', $url )."' async='async";
	    }
	}
	add_filter( 'clean_url', 'async_scripts', 11, 1 );

	add_action('wp_enqueue_scripts', 'project_styles' );
	function project_styles() {
		wp_enqueue_style('main', get_stylesheet_directory_uri() .'/style.min.css', array(), null);
	}

	add_action('wp_enqueue_scripts', 'project_scripts' ); // хук автоматом сработает во время wp_head
	function project_scripts() {
		wp_register_script('modernizr', get_stylesheet_directory_uri() .'/js/modernizr-custom.js', array(), null, false);
		wp_enqueue_script('modernizr');
		
		wp_deregister_script( 'jquery' );
		wp_register_script('jquery', get_stylesheet_directory_uri() .'/js/jquery.min.js', array(), null, false);
		wp_enqueue_script('jquery');

		wp_register_script('picturefill', get_stylesheet_directory_uri() .'/js/picturefill.min.js#asyncload', array(), null, false);
		wp_enqueue_script('picturefill');


		wp_register_script('loader', get_stylesheet_directory_uri() .'/js/loader.js', array('jquery'), null, false);
		wp_enqueue_script('loader');

		wp_add_inline_script('picturefill', 'document.createElement( "picture" );', 'before');

		wp_register_script('libs', get_stylesheet_directory_uri() .'/js/libs.min.js', array(), null, true);
		wp_enqueue_script('libs');

		wp_register_script('plugins', get_stylesheet_directory_uri() .'/js/plugins.js', array('jquery', 'libs'), null, true);
		wp_enqueue_script('plugins');

		wp_register_script('main', get_stylesheet_directory_uri() .'/js/main.min.js', array('jquery','libs', 'plugins'), null, true);
		wp_enqueue_script('main');

		wp_register_script('ajaxPostLoader', get_stylesheet_directory_uri() .'/js/ajaxPostLoader.js', array('jquery'), null, true);

		if(is_home() or is_page('portfolio') or is_tax('portfolio')) {
			wp_enqueue_script('ajaxPostLoader');
		}
	}

	add_action( 'wp_enqueue_scripts', 'myajax_data', 99 );
	function myajax_data(){
		wp_localize_script('ajaxPostLoader', 'myajax', 
			array(
				'url' => admin_url('admin-ajax.php')
			)
		); 

		wp_localize_script('main', 'myajax', 
			array(
				'url' => admin_url('admin-ajax.php')
			)
		);  
	}

	add_action('after_setup_theme', function(){
		register_nav_menus( array(
			'header_menu' => 'Меню в шапке'
		) );
	});

	# Виджеты
	include_once('widgets/case-text-block.php');
	include_once('widgets/opening-block.php');

	# ссылка на архив таксономии
	function get_taxonomy_archive_link( $taxonomy ) {
		$tax = get_taxonomy( $taxonomy ) ;
		return get_bloginfo( 'url' ) . '/' . $tax->rewrite['slug'];
	}

	function nl_to_li($str) {
		$string = '<li>';
		$string .= str_replace(array("\r\n", "\r", "\n"), "</li><li>", $str);
		$string .= '</li>';
		return $string;
	}

	# Замена стандартного шорткода галереи
	add_filter('post_gallery', 'my_gallery_output', 10, 2);
	function my_gallery_output( $output, $attr ){
		$ids_arr = array_map('trim', $attr['ids'] );

		$pictures = get_posts( array(
			'posts_per_page' => -1,
			'post__in'       => $ids_arr,
			'post_type'      => 'attachment',
			'orderby'        => 'post__in',
		) );

		$out = '
			<div class="simple-slider case__slider">
			    <div class="simple-slider__container swiper-container">
			        <div class="simple-slider__track swiper-wrapper">
		';
					foreach( $pictures as $pic ):
						$src = $pic->guid;
						$t = esc_attr( $pic->post_title );
						$title = ( $t && false === strpos($src, $t)  ) ? $t : '';

			        	$out .= '
			            <div class="simple-slider__item swiper-slide">
			                <img src="'.$src.'" alt="'.$title.'">
			            </div>';
			        endforeach;
		$out .= '
			        </div>
			    </div>
			    <div class="simple-slider__dots swiper-pagination"></div>
			</div>';

		return $out;
	}

	# Подгрузка ленты
	add_action('wp_ajax_load_posts', 'load_posts');
	add_action('wp_ajax_nopriv_load_posts', 'load_posts');
	function load_posts() {
		$paged = isset($_POST['paged']) ? $_POST['paged'] : '';
		$category = isset($_POST['category']) ? $_POST['category'] : '';
		$offset = isset($_POST['offset']) ? $_POST['offset'] : '';
		$number = isset($_POST['number']) ? $_POST['number'] : '';
		$type = isset($_POST['type']) ? $_POST['type'] : 'post';
		$template = isset($_POST['template']) ? $_POST['template'] : 'blog';
		$tax = isset($_POST['tax']) ? $_POST['tax'] : 'category';
		$term = isset($_POST['term']) ? $_POST['term'] : '';
		$modal = false;

		$return = array();
		$return['paged'] = $paged;
		$return['template'] = $template;
		$return['offset'] = $offset;
		$return['number'] = $number;
		$return['type'] = $type;
		$return['category'] = $category;
		$return['cards'] = array();
		$return['modals'] = array();

		$query = new WP_Query( 
			array( 
				'paged' => empty($offset) ? $paged : '',
				'cat' => $category,
				'posts_per_page' => !empty($number) ? $number : get_option( 'posts_per_page' ),
				'offset' => $offset,
				'post_type' => $type,
				$tax => $term
				// 'category__not_in' => get_field('exclude_cat', get_option( 'page_for_posts' ))
			)
		);

		if($query->have_posts()){
			while ( $query->have_posts() ){
				$query->the_post();

				switch($template) {
					case 'case': 
						$return['cards'][] = '<div class="portfolio__item">'.case_card().'</div>';
						break;
					default: 
						$return['cards'][] = blog_card();
						break;
				}
				
				// if($modal) {
				// 	$return['modals'][] = load_template_part('template-parts/p-modal', $template);
				// }
			}

			$return['hide_btn'] = $query->post_count < $number ? true : false;
			wp_reset_postdata();
		}


		echo json_encode($return);

		die();
	}

	# Выводит шапку сайта.
	include_once('components/header/functions.php');

	# Функция для вывода промо на главной.
	include_once('components/digital/functions.php');

	# Выводит слайдер с услугами.
	include_once('components/services/functions.php');

	# выводит плитки портфолио
	include_once('components/portfolio/functions.php');

	# Комплексный компонент обратной связи
	include_once('components/feedback/functions.php');

	# выводит секцию с партнерами
	include_once('components/partners/functions.php');

	# выводит секцию контакты
	include_once('components/contacts/functions.php');

	# превью записи в блоге
	include_once('components/blog-card/functions.php');

	# Слайдер с этапами
	include_once('components/case-slider/functions.php');


	# Вложенные пункты меню
	function wp_get_menu_array($current_menu) {

		$array_menu = wp_get_nav_menu_items($current_menu);
		$menu = array();
		$submenu = array();
		$subsubmenu = array();

		foreach ($array_menu as $m) {
			if (empty($m->menu_item_parent)){
				$curent_id = $m->object_id;
				$menu[$m->object_id] = array();
				$menu[$m->object_id]['ID']          =   $m->object_id;
				$menu[$m->object_id]['title']       =   $m->title;
				$menu[$m->object_id]['url']         =   $m->url;
				$menu[$m->object_id]['submenu']     =   array();
			}

			if ($m->menu_item_parent == $curent_id) {
				$curent_sub_id = $m->object_id;
				$submenu[$m->object_id] = array();
				$submenu[$m->object_id]['ID']       =   $m->object_id;
				$submenu[$m->object_id]['title']    =   $m->title;
				$submenu[$m->object_id]['url']      =   $m->url;
				$submenu[$m->object_id]['subsubmenu']  =   array();
				$menu[$m->menu_item_parent]['submenu'][$m->object_id] = $submenu[$m->object_id];
			}

			if ($m->menu_item_parent == $curent_sub_id) {
				$subsubmenu[$m->object_id] = array();
				$subsubmenu[$m->object_id]['ID']       =   $m->object_id;
				$subsubmenu[$m->object_id]['title']    =   $m->title;
				$subsubmenu[$m->object_id]['url']      =   $m->url;
				$menu[$curent_id]['submenu'][$curent_sub_id]['subsubmenu'][$m->object_id] = $subsubmenu[$m->object_id];
			}
		}

		return $menu;   
	}

	function animation_scripts() {
		if(is_page('promotion')) {
			print("
				<script>
				    $('#context-phone').css('opacity', 0);
				    $('#context-phone').waypoint(function() {
				        $('#context-phone').addClass('fadeInRight');
				    }, { offset: '50%' })

				    $('.case-common__img--land').css('opacity', 0);
				    $('.case-common__img--land').waypoint(function() {
				        $('.case-common__img--land').addClass('fadeIn');
				    }, { offset: '50%' })

				    $('.case-common__img--phone').css('opacity', 0);
				    $('.case-common__img--phone').waypoint(function() {
				        $('.case-common__img--phone').addClass('fadeIn');
				    }, { offset: '50%' })

				</script>
			");
		}

		if(is_page('design')) {
			print("
				<script>
				    $('#colors').css('opacity', 0);
				    $('#colors').waypoint(function() {
				        $('#colors').addClass('fadeInUp');
				    }, { offset: '100%' })

				    $('#balloon').css('opacity', 0);
				    $('#balloon').waypoint(function() {
				        $('#balloon').addClass('fadeInUp');
				    }, { offset: '100%' })

				    $('#visitka').css('opacity', 0);
				    $('#visitka').waypoint(function() {
				        $('#visitka').addClass('fadeInUp');
				    }, { offset: '100%' })

				    $('#sofora').css('opacity', 0);
				    $('#sofora').waypoint(function() {
				        $('#sofora').addClass('fadeInUp');
				    }, { offset: '100%' })

				    $('#note').css('opacity', 0);
				    $('#note').waypoint(function() {
				        $('#note').addClass('fadeInUp');
				    }, { offset: '100%' })
				</script>
			");
		}

		if(is_page('sites')) {
			print("
				<script>
				    $('#site3').css('opacity', 0);
				    $('#site3').waypoint(function() {
				        $('#site3').addClass('fadeInUp');
				    }, { offset: '50%' })

				    $('#site2').css('opacity', 0);
				    $('#site2').waypoint(function() {
				        $('#site2').addClass('fadeInUp');
				    }, { offset: '50%' })

				    $('#site1').css('opacity', 0);
				    $('#site1').waypoint(function() {
				        $('#site1').addClass('fadeInUp');
				    }, { offset: '50%' })

				    $('#floor').css('opacity', 0);
				    $('#floor').waypoint(function() {
				        $('#floor').addClass('fadeIn');
				    }, { offset: '50%' })

				    $('#am-phone').css('opacity', 0);
				    $('#am-phone').waypoint(function() {
				        $('#am-phone').addClass('fadeInRight');
				    }, { offset: '50%' })

				    $('#metrika').css('opacity', 0);
				    $('#metrika').waypoint(function() {
				        $('#metrika').addClass('fadeInRight');
				    }, { offset: '50%' })

				    $('.case-common__img--am-1').css('opacity', 0);
				    $('.case-common__img--am-1').waypoint(function() {
				        $('.case-common__img--am-1').addClass('fadeIn');
				    }, { offset: '50%' })

				    $('.case-common__img--am-2').css('opacity', 0);
				    $('.case-common__img--am-2').waypoint(function() {
				        $('.case-common__img--am-2').addClass('fadeIn');
				    }, { offset: '50%' })
				</script>
			");
		}

		if(is_page('smm')) {
			print("
				<script>
				    $('#smm1').css('opacity', 0);
				    $('#smm1').waypoint(function() {
				        $('#smm1').addClass('fadeInUp');
				    }, { offset: '50%' })

				    $('#smm2').css('opacity', 0);
				    $('#smm2').waypoint(function() {
				        $('#smm2').addClass('fadeInUp');
				    }, { offset: '50%' })

				    $('#smm3').css('opacity', 0);
				    $('#smm3').waypoint(function() {
				        $('#smm3').addClass('fadeInUp');
				    }, { offset: '50%' })

				    $('#kirvi-wall').css('opacity', 0);
				    $('#kirvi-wall').waypoint(function() {
				        $('#kirvi-wall').addClass('fadeInRight');
				    }, { offset: '50%' })

				    $('#context-phone').css('opacity', 0);
				    $('#context-phone').waypoint(function() {
				        $('#context-phone').addClass('fadeInRight');
				    }, { offset: '50%' })
				</script>
			");
		}
	}
