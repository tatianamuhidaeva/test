<section class="hero header__hero">
    <div class="hero__title"><?php echo $page_header['hero']['title']; ?></div>
    <div class="hero__img" role="presentation">
		<?php if($page_header['hero']['video']): ?>
		    <video autoplay buffered loop muted preload banner="<?php echo $page_header['hero']['image']; ?>">
		    	<?php for ($i = 0; $i < count($page_header['hero']['video']); $i++): ?>
		    	<source src="<?php echo $page_header['hero']['video'][$i]['src']; ?>" type="<?php echo $page_header['hero']['video'][$i]['type']; ?>">
		    	<?php endfor; ?>
		    	<img src="<?php echo $page_header['hero']['image']; ?>" alt="Hero img">	    
		    </video>
        <?php endif; ?>
    	<img src="<?php echo $page_header['hero']['image']; ?>" alt="Hero img">
    </div>
</section>