<?php
	function case_slider_item($args = array()) {

		$default_args = array(
			'css_class' => '',
			'i' => 0,
			'title' => 'Название этапа',
			'text' => '',
			'img_id' => null
		);
		$args = array_replace_recursive($default_args, $args);

		ob_start();
		set_query_var('case_slider_item', $args);
		get_template_part('components/case-slider/item');
		$component = ob_get_contents();
		ob_end_clean();

		return $component;
	}