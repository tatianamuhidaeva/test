<div class="slider__item <?php echo $case_slider_item['css_class']; ?>">
    <div class="promo">
        <div class="promo__inner">
        	<i class="promo__i" data-content="<?php echo $case_slider_item['i']; ?>"><?php echo $case_slider_item['i']; ?></i>
        	<h3 class="promo__title" data-content="<?php echo $case_slider_item['title']; ?>"><?php echo $case_slider_item['title']; ?></h3>
        	<div class="promo__text">
        	    <?php echo wpautop($case_slider_item['text']); ?>
        	</div>
        </div>
        <img src="<?php echo wp_get_attachment_image_url( $case_slider_item['img_id'], 'full'); ?>" alt="<?php echo $case_slider_item['title']; ?>" class="promo__img" rel="nofollow" role="presentation">
    </div>
</div>