<?php
	function contacts($args = array()) {
		
		$default_args = array(
			'title' => 'контакты',
			'visible_title' => true,
			'title_color' => 'purple', // Модификатор в css (black, white, purple)
		);
		$args = array_replace_recursive($default_args, $args);

		set_query_var('contacts', $args);
		get_template_part('components/contacts/contacts');
	}