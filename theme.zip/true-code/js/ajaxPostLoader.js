jQuery(document).ready(function ($) {
  if ($('#postLoaderToggler').length) {
    var paged = 2;
    var offset = $('#postLoaderToggler').is('[data-offset]') ? +$('#postLoaderToggler').attr('data-offset') : '';
    $('#postLoaderToggler').on('click', function () {
      $.ajax({
        url: myajax.url,
        type: 'POST',
        data: {
          paged: paged,
          category: $('#postLoaderToggler').attr('data-category'),
          offset: offset,
          number: $('#postLoaderToggler').is('[data-show]') ? +$('#postLoaderToggler').attr('data-show') : '',
          type: $('#postLoaderToggler').attr('data-type'),
          template: $('#postLoaderToggler').attr('data-template'),
          term: $('#postLoaderToggler').attr('data-term'),
          tax: $('#postLoaderToggler').attr('data-tax'),
          action: 'load_posts'
        },
        beforeSend: function () {
          $("#postLoaderToggler").addClass('wait');
        },
        success: function (data) {
          $("#postLoaderToggler").removeClass('wait');
          var data = JSON.parse(data); // console.log(data);

          if (offset != '') {
            offset += +data.number;
          }

          if (data.cards.length) {
            paged++;

            for (var i = 0; i < data.cards.length; i++) {
              $('#postLoaderContent').append(data.cards[i]);
            }
          }

          if (data.hide_btn) {
            $("#postLoaderToggler").hide();
          }
        }
      });
    });
  }
});