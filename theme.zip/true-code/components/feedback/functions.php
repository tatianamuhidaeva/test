<?php
	# выводит секцию с формой обратной связи
	function bid($args = array()) {
		
		$default_args = array(
			'title' => 'Онлайн заявка',
			'visible_title' => false,
			'title_color' => 'white', // Модификатор в css (black, white, purple)
		);
		$args = array_replace_recursive($default_args, $args);

		set_query_var('bid', $args);
		get_template_part('components/feedback/bid');
	}

	require(get_stylesheet_directory_uri() . '/mailer/PHPMailerAutoload.php');

	// Отправка формы по умолчанию
	add_action('wp_ajax_bid_form', 'bid_form');
	add_action('wp_ajax_nopriv_bid_form', 'bid_form');
	function bid_form() { 

		$mail = new PHPMailer;
		$mail->setFrom('support@t-code.ru', 'Сайт t-code.ru');
		$mail->addAddress('support@t-code.ru');
		$mail->IsHTML(true);
		$mail->CharSet = 'UTF-8';

		$form = $_POST['form'];
	    $mail->Subject = 'Отправлено с сайта t-code.ru';
	    $mail->Body = '';

		foreach($form as $data){
			switch($data['name']){
				case 'subject': 
					$mail->Subject = $data['value']; 
					break;

				case 'name': 
					$mail->Body .= 'Имя: '.$data['value'].'<br>'; 
					break;

				case 'email': 
					$mail->Body .= 'Email: '.$data['value'].'<br>'; 
					break;

				case 'phone': 
					$mail->Body .= 'Телефон: '.$data['value'].'<br>'; 
					break;

				case 'message': 
					$mail->Body .= 'Сообщение: '.$data['value'].'<br><br>'; 
					break;

				case 'services': 
					$mail->Body .= 'Услуга: '.$data['value'].'<br>'; 
					break;

				case 'terms': 
					$mail->Body .= $data['value'].'<br>'; 
					break;
					
			}
		}
		
		$mail->Send();

		die();
	}