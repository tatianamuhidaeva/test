<?php

class Opening_block extends WP_Widget {

	// Регистрация виджета используя основной класс
	function __construct() {
		parent::__construct(
			'',
			'Раздел вакансии',
			array( 
				'description' => 'Для оформления вакансии', 
				/*'classname' => 'my_widget',*/ 
			)
		);
	}

	/**
	 * Вывод виджета во Фронт-энде
	 *
	 * @param array $args     аргументы виджета.
	 * @param array $instance сохраненные данные из настроек
	 */
	function widget( $args, $instance ) {
		$title = apply_filters( 'widget_title', $instance['title'] );
		$description = apply_filters( 'widget_description', $instance['description'] );

		if(!empty($title)){
			echo '<h4 class="opening__subtitle">'.$title.'</h4>';
		}

    	if(!empty($description)){
    		echo '<ul class="opening__list">';
    		echo nl_to_li(strip_tags($description, '<a>'));
    		echo '</ul>';
    	}
			      
	}

	/**
	 * Админ-часть виджета
	 *
	 * @param array $instance сохраненные данные из настроек
	 */
	function form( $instance ) {
		$title = @ $instance['title'] ?: '';
		$description = @ $instance['description'] ?: '';
		?>
		<p>
			<label for="<?php echo $this->get_field_id( 'title' ); ?>"><?php _e( 'Заголовок:' ); ?></label> 
			<input class="widefat" id="<?php echo $this->get_field_id( 'title' ); ?>" name="<?php echo $this->get_field_name( 'title' ); ?>" type="text" value="<?php echo esc_attr( $title ); ?>">
		</p>

		<p>
			Перенос строки добавляет новый пункт в список
			<label for="<?php echo $this->get_field_id( 'description' ); ?>"><?php _e( 'Текст:' ); ?></label> 
			<textarea class="widefat" id="<?php echo $this->get_field_id( 'description' ); ?>" name="<?php echo $this->get_field_name( 'description' ); ?>" rows="5"><?php echo esc_attr( $description ); ?></textarea> 
		</p>
		
		<?php 
	}

	/**
	 * Сохранение настроек виджета. Здесь данные должны быть очищены и возвращены для сохранения их в базу данных.
	 *
	 * @see WP_Widget::update()
	 *
	 * @param array $new_instance новые настройки
	 * @param array $old_instance предыдущие настройки
	 *
	 * @return array данные которые будут сохранены
	 */
	function update( $new_instance, $old_instance ) {
		$instance = array();
		$instance['title'] = ( ! empty( $new_instance['title'] ) ) ? strip_tags( $new_instance['title'] ) : get_the_title($post_id);
		$instance['description'] = ( ! empty( $new_instance['description'] ) ) ? strip_tags( $new_instance['description'] ) : '';

		return $instance;
	}
} 


// регистрация в WordPress
function register_opening_block() {
	register_widget( 'Opening_block' );
}
add_action( 'widgets_init', 'register_opening_block' );