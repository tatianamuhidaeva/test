<header class="header <?php echo $page_header['css_class']; ?>">
    <h1 class="invisible"><?php echo $page_header['title']; ?></h1>

    <?php get_template_part('components/header/navbar'); ?>

    <?php 
        /**
         * Слайдер проектов от старого макета
         * $page_header['case'] => false (См. components/header/view/)
         */
    ?>
    <?php if($page_header['case']): ?>
        <section class="header__slider">
            <div class="container">
                <h2 class="invisible"><?php echo $page_header['case']['title']; ?></h2>
            </div>
            <?php get_template_part('components/header/case-slider'); ?>
        </section>

        <a href="https://agima.partners/?utm_source=together-with-agima&utm_medium=beydzh&utm_campaign=t-code">
            <img src="<?php bloginfo('template_url')?>/img/case-slider/ribbon-black.png" alt="ribbon-black" style="position: fixed; top: 130px; left: 0; width: 100px; height: auto; z-index: 99;">
        </a>

        <div class="header__scroll-down" rel="nofollow" role="presentation"></div>
        <div class="header__socials">
            <a href="https://vk.com/truecode38" target="_blank">Вк</a>
            <a href="https://www.facebook.com/truecode38/" target="_blank">Fb</a>
            <a href="https://www.instagram.com/true.code/" target="_blank">Insta</a>
        </div>
    <?php endif; ?>
    <?php 
        /**
         * end of old case slider
         */
    ?>

    <?php if($page_header['hero']) { get_template_part('components/header/hero'); } ?>
</header>