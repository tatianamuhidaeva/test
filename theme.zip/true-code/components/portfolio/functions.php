<?php
	function portfolio($args = array()) {	
		$default_args = array(
			'title' => 'Портфолио',
			'visible_title' => true,
			'title_color' => 'black', // Модификатор в css (black, white, purple)
			'nav' => array(),
			'posts_per_page' => 9,
			'show_portfolio_link' => true
		);
		$args = array_replace_recursive($default_args, $args);

		set_query_var('portfolio', $args);
		get_template_part('components/portfolio/portfolio');
	}

	function case_card() {	
		ob_start();
		get_template_part('components/portfolio/case-card');
		$component = ob_get_contents();
		ob_end_clean();

		return $component;
	}