<div class="opening">
    <div class="container">
        <div class="pr-8--tablet pl-8--tablet">
            <?php 
                $query = new WP_Query(array(
                    'post_type' => 'opening',
                    'order' => 'DESC',
                    'orderby' => 'date'
                ));
                if ($query->have_posts()): 
                    echo '<h2 class="opening__title">Вакансии</h2> ';
                    while ($query->have_posts()): $query->the_post();
                        # Компонент вакансии
                        get_template_part('components/opening/item');  
                    endwhile;
                    wp_reset_query();
                else:
                    get_template_part('components/opening/junior');  
                endif; 
            ?>
        </div>
    </div>
</div>