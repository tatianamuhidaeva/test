<?php get_header(); the_post(); ?>
<?php 
    # Выводит шапку сайта. (components/header)
   get_template_part('components/header/view'); 

?>
<section class="case">
    <div class="container container--sm">
        <div class="case__description">
            <p><strong>SMM (Social Media Marketing)</strong> — комплекс мероприятий по продвижению продукта, бренда или компании в социальных сетях. Успех этого направления в сфере интернет-рекламы вызван непрерывно растущей популярностью социальных сетей.</p>
            <p>Основным элементом SMM является контент. В грамотно выстроенной SMM-кампании он будет распространяться пользователями без участия организатора.</p>
            <p>Ключ к успеху в SMM – социальные связи, лежащие в основе взаимодействия пользователей. Благодаря ним распространение информации носит более доверительный характер в сравнении с другими каналами интернет-рекламы.</p>
        </div>
    </div>

    <div class="container container--sm">
       <div class="case__text-block clearfix">
           <h2 class="case__title invisible">Продвижение бизнеса в социальных сетях</h2>
           <span id="context-phone" class="animated" rel="nofollow" role="presentation">
               <picture>
                   <source type="image/webp" srcset="<?php bloginfo('template_url')?>/img/general/iphone-smm.webp">
                   <img src="<?php bloginfo('template_url')?>/img/general/iphone-smm.png" alt="SMM">
               </picture>
           </span>
           <div class="pt-10--tablet">
               <p>Продвижение бизнеса в социальных сетях – это разносторонняя работа, включающая оформление аккаунта, создание оригинального контента и ведение сообщества, настройка и ведение рекламной кампании, работа с аудиторией и возражениями, аналитика проделанной работы за месяц.</p>
               <p>На сегодняшний день люди ищут товары и услуги не только через поисковые запросы, но и, например, по хештегам в инстаграме. Поэтому именно комплексная работа по продвижению бренда поможет достигнуть максимально эффективных результатов. Ведь ваши услуги ищут в соцсетях.</p>
           </div>
       </div>

       <div class="case__text-block mb-0">
           <h2 class="case__title">Этапы работы по продвижению в социальных сетях</h2>
       </div>
    </div>
    
    <div class="slider case__slider" role="slider">
        <div class="slider__container my-5 my-8--notebook">
            <?php get_template_part('components/case-slider/slider'); ?>
        </div>
    </div>

    <div class="container">
        <div class="case__text-block">
            <h2 class="case__title case__title--center">Как выглядит реклама в социальных сетях?</h2>
            <h3 class="case__subtitle text-center my-3">Каждая социальная сеть имеет свои особенности<br>и вид рекламных объявлений.</h3>
        </div>
    </div>

    <div class="common-block common-block--smm" rel="nofollow" role="presentation">
        <div class="container">
            <span id="smm1" class="animated" rel="nofollow" role="presentation">
                <picture>
                    <source type="image/webp" srcset="<?php bloginfo('template_url')?>/img/general/smm-inst.webp">
                    <img src="<?php bloginfo('template_url')?>/img/general/smm-inst.png" alt="SMM">
                </picture>
            </span>
            <span id="smm2" class="animated" rel="nofollow" role="presentation">
                <picture>
                    <source type="image/webp" srcset="<?php bloginfo('template_url')?>/img/general/smm-vk.webp">
                    <img src="<?php bloginfo('template_url')?>/img/general/smm-vk.png" alt="SMM">
                </picture>
            </span>
            <span id="smm3" class="animated" rel="nofollow" role="presentation">
                <picture>
                    <source type="image/webp" srcset="<?php bloginfo('template_url')?>/img/general/smm-fb.webp">
                    <img src="<?php bloginfo('template_url')?>/img/general/smm-fb.png" alt="SMM">
                </picture>
            </span>
        </div>
    </div>

    <div class="container container--sm">
        <div class="case__text-block">
            <h2 class="case__title case__title--center">Кому показывается реклама?</h2>
            <p>Ваше рекламное объявление будет показано только тем, кто заинтересован вашим предложением. Это помогает не только направить ваше объявление строго на целевую аудиторию, но и сэкономить бюджет из-за того, чтобы люди, не готовые к покупке ваших товаров или услуг не «скликивали» рекламный бюджет. </p>
            <p>Помимо того, что мы самостоятельно настраиваем целевую аудиторию, рекламная сеть сама определяет тому, кому стоит показать объявление: например, по последним запросам пользователя в поисковых системах или по интересу к тем или иным аккаунтам смежных тематик. </p>
        </div>
    </div>

    <div class="case-common case-common--instroytech">
        <div class="case-common__inner">
            <span class="case-common__img case-common__img--land animated" rel="nofollow" role="presentation">
                <picture>
                    <source type="image/webp" srcset="<?php bloginfo('template_url')?>/img/general/img-1.webp">
                    <img src="<?php bloginfo('template_url')?>/img/general/img-1.png" alt="Пример работы Инстройтех-С">
                </picture>
            </span>
            
            <span  class="case-common__img case-common__img--phone animated" rel="nofollow" role="presentation">
                <picture>
                    <source type="image/webp" srcset="<?php bloginfo('template_url')?>/img/general/phone.webp">
                    <img src="<?php bloginfo('template_url')?>/img/general/phone.png" alt="Пример работы Инстройтех-С">
                </picture>
            </span>
            
            <div class="case-common__blank">
                <span class="case-common__logo" rel="nofollow" role="presentation">
                    <picture>
                        <source type="image/webp" srcset="<?php bloginfo('template_url')?>/img/general/instr.webp">
                        <img src="<?php bloginfo('template_url')?>/img/general/instr.png" alt="Пример работы Инстройтех-С">
                    </picture>
                </span>
                
                <div class="case-common__text">
                    <p>Например, как мы это сделали<br>для строительной компании<br>«Инстройтех-С»</p>
                    <a href="<?php echo get_site_url().'/case/instroytech'; ?>" class="case-common__link">Посмотреть кейс</a>
                </div>
            </div>
        </div>
    </div>
</section>

<?php 
    # выводит секцию с формой обратной связи. (components/feedback/bid)
    bid(array(
        'visible_title' => false
    ));
?>

<footer class="case-footer pb-10">
    <nav class="case-footer__nav case-footer__nav--around">
        <a href="<?php echo get_site_url().'/promotion'; ?>" class="btn btn--back btn--white case-footer__back">Контекстная реклама</a>
        <a href="<?php echo get_site_url().'/sites'; ?>" class="btn btn--next btn--white case-footer__next">Создание сайтов</a>
    </nav>
</footer>

<?php get_footer(); ?>