<div class="case-slide">
	<div class="invisible">
		<h3>Irkutsk Behance portfolio review v.3</h3>
	</div>

	<div class="case-slide__animate behance-case" rel="nofollow" role="presentation">
		<img src="<?php bloginfo('template_url')?>/img/case-slider/behance-text.png" alt="" class="behance-case__img behance-case__img--layer1">      
		<img src="<?php bloginfo('template_url')?>/img/case-slider/behance-head.png" alt="" class="behance-case__img behance-case__img--layer2">      
		<img src="<?php bloginfo('template_url')?>/img/case-slider/behance-exibit.png" alt="" class="behance-case__img behance-case__img--layer3"> 
	</div>

	<div class="case-slide__preview" rel="nofollow" role="presentation">
		<picture>
			<source type="image/webp" srcset="<?php bloginfo('template_url')?>/img/case-slider/bundle-be-1x.webp 1x, <?php bloginfo('template_url')?>/img/case-slider/bundle-be-2x.webp 2x">
			<img srcset="<?php bloginfo('template_url')?>/img/case-slider/bundle-be-1x.png 1x, <?php bloginfo('template_url')?>/img/case-slider/bundle-be-2x.png 2x" src="<?php bloginfo('template_url')?>/img/case-slider/bundle-be-2x.png" alt="Превью кейса">
		</picture>
	</div>
	<a href="<?php echo get_site_url().'/case/behance-portfolio-review/'; ?>" class="btn btn--a case-slide__btn">Посмотри кейс</a>
</div>