	        <?php get_template_part('components/modals/modals'); ?>
	        <?php wp_footer(); ?>
	        <?php animation_scripts(); ?>
    	</div>
    </body>
</html>