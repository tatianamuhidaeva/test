<div class="case-slide">
	<div class="invisible">
		<h3>Меткий</h3>
		<small>бильярдный клуб</small>
	</div>
	<div class="case-slide__animate metkii-case" rel="nofollow" role="presentation">
		<img src="<?php bloginfo('template_url')?>/img/case-slider/metkii-purpleball.png" alt="" class="metkii-case__img metkii-case__img--layer1">      
		<img src="<?php bloginfo('template_url')?>/img/case-slider/metkii-greenball.png" alt="" class="metkii-case__img metkii-case__img--layer2">      
		<img src="<?php bloginfo('template_url')?>/img/case-slider/metkii-blackball.png" alt="" class="metkii-case__img metkii-case__img--layer3">
		<div class="case-slide__title">Меткий</div>  
	</div>
	<div class="case-slide__preview" rel="nofollow" role="presentation">
		<picture>
			<source type="image/webp" srcset="<?php bloginfo('template_url')?>/img/case-slider/bundle-metkii-1x.webp 1x, <?php bloginfo('template_url')?>/img/case-slider/bundle-metkii-2x.webp 2x">
			<img srcset="<?php bloginfo('template_url')?>/img/case-slider/bundle-metkii-1x.png 1x, <?php bloginfo('template_url')?>/img/case-slider/bundle-metkii-2x.png 2x" src="<?php bloginfo('template_url')?>/img/case-slider/bundle-metkii-2x.png" alt="Превью кейса">
		</picture>
	</div>
	<a href="<?php echo get_site_url().'/case/metkii'; ?>" class="btn btn--a case-slide__btn">Посмотри кейс</a>
</div>