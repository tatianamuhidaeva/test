<?php $uid = uniqid(); ?>
<div class="opening__item" id="<?php echo $uid; ?>">
    <h3 class="opening__name spoiler-open" data-target="<?php echo '#'.$uid; ?>"><?php the_title(); ?></h3>
    <div class="opening__spoiler">
        <?php the_content(); ?>
        <div class="opening__item-footer">
            <a href="<?php echo '#vacancy-'.$uid; ?>" class="btn btn--d" data-toggle="modal" onclick="ym(38838170, 'reachGoal', 'rabota'); return true;">Хочу работать</a>
            <span class="opening__close">Свернуть</span>
        </div>
    </div>

    <div class="modal-layout" id="<?php echo 'vacancy-'.$uid; ?>" role="dialog">
        <div class="modal modal--auto">
            <div class="modal__close">✖</div>
            <div class="modal__header text-center">Отзыв на вакансию<br>(<?php the_title(); ?>)</div>
            <div class="modal__body">
                <form class="bid__form envelope">
                    <div class="envelope__body">
                        <div class="envelope__fieldset">
                            <label for="<?php echo 'name-'.$uid; ?>" class="envelope__label">Имя</label>
                            <input type="text" id="<?php echo 'name-'.$uid; ?>" name="name" class="envelope__form-control" required>
                        </div>
                        <div class="envelope__fieldset">
                            <label for="<?php echo 'email-'.$uid; ?>" class="envelope__label">Email</label>
                            <input type="email" id="<?php echo 'email-'.$uid; ?>" name="email" class="envelope__form-control" required>
                        </div>
                        <div class="envelope__fieldset">
                            <label for="<?php echo 'phone-'.$uid; ?>" class="envelope__label">Телефон</label>
                            <input type="text" id="<?php echo 'phone-'.$uid; ?>" name="phone" class="envelope__form-control" data-mask="+7(000)000-00-00" required>
                        </div>
                        <div class="envelope__fieldset">
                            <label for="<?php echo 'message-'.$uid; ?>" class="envelope__label envelope__label--for-textarea">Сообщение</label>
                            <textarea name="message" id="<?php echo 'message-'.$uid; ?>" rows="4" class="envelope__textarea-control"></textarea>
                        </div>
                    </div>
                    <div class="envelope__footer text-center">
                        <div class="envelope__fieldset">
                            <label for="<?php echo 'terms-'.$uid; ?>" class="envelope__label politica">
                                <input type="checkbox" name="terms" id="<?php echo 'terms-'.$uid; ?>" class="invisible" value="Я принимаю политику конфиденциальности">
                                <span class="envelope__checkbox-control envelope__checkbox-control--pink"></span>
                                Я принимаю политику конфиденциальности
                            </label>
                        </div>
                        <input type="hidden" name="subject" value="Отзыв на вакансию: <?php the_title(); ?>">
                        <button type="submit" class="btn btn--a envelope__btn disabled" onclick="ym(38838170, 'reachGoal', 'rabota_zayavka'); return true;">Отправить</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>