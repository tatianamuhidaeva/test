<section class="promo-text">
   <div class="promo-text__front container container--md">
      <div class="promo-text__word">
         <span class="promo-text__letter" data-letter="D">D</span>
         <span class="promo-text__letter" data-letter="I">I</span>
         <span class="promo-text__letter" data-letter="G">G</span>
         <span class="promo-text__letter" data-letter="I">I</span>
         <span class="promo-text__letter" data-letter="T">T</span>
         <span class="promo-text__letter" data-letter="A">A</span>
         <span class="promo-text__letter" data-letter="L">L</span>
      </div>
      <div class="promo-text__word promo-text__word--right">
         <span class="promo-text__letter" data-letter="A">A</span>
         <span class="promo-text__letter" data-letter="G">G</span>
         <span class="promo-text__letter" data-letter="E">E</span>
         <span class="promo-text__letter" data-letter="N">N</span>
         <span class="promo-text__letter" data-letter="C">C</span>
         <span class="promo-text__letter" data-letter="Y">Y</span>
      </div>
      <div class="promo-order">
         <p>
            Мы занимаемся созданием сайтов и интерфейсов, брендингом, придумываем рекламу и развиваем проекты в digital.
         </p>
         <a href="#ask" class="btn btn--b promo-order__btn" data-toggle="modal">Подать заявку</a>
      </div>
   </div>

   <div class="promo-text__back">
      <div class="container container--md">
         <div>
            <div class="promo-text__rand">Диджитал<br>агентство</div>
            <div class="promo-text__rand">Design</div>
            <div class="promo-text__rand">Dev</div>
            <div class="promo-text__rand">SMM</div>
            <div class="promo-text__rand">SEO</div>
            <div class="promo-text__rand">TRUE</div>
            <div class="promo-text__rand">CODE</div>
         </div>
         <div>
            <div class="promo-text__slash" rel="nofollow"></div>
            <div class="promo-text__slash" rel="nofollow"></div>
            <div class="promo-text__slash" rel="nofollow"></div>
            <div class="promo-text__slash" rel="nofollow"></div>
         </div>
      </div>
   </div>
</section>

<section class="promo-partners">
   <div class="container container--md">
      <div class="promo-partners__text">
         <?= wpautop(get_field('partners')['text']); ?>
      </div>
      <?php $logos = get_field('partners')['logos']; 
      if($logos): ?>

      <div class="promo-logos">
         <?php foreach( $logos as $logo ): ?>
         <div class="promo-logos__item">
            <img src="<?php echo wp_get_attachment_image_url( $logo['ID'], 'medium' ); ?>" alt="<?= $logo['alt']; ?>">
         </div>
         <?php endforeach; ?>
      </div>

      <?php endif; ?>
   </div>
</section>

<section class="promo-case">
   <div class="container container--md">
      <h2 class="promo-case__title">Наша последняя работа</h2>
      <div class="last-project">
         <div class="dotted dotted--hor last-project__dotted last-project__dotted--one">
            <img src="<?php bloginfo('template_url')?>/img/general/dotted.svg" alt="" rel="nofollow">
         </div>
         <div class="line last-project__line last-project__line--three"></div>
         <div class="last-project__tilt" data-tilt="" data-tilt-maxtilt="20" data-tilt-speed="1000" data-tilt-perspective="1500">
            <div class="last-project__image">
               <a href="<?= get_field('last_project')['link']; ?>"><img src="<?= wp_get_attachment_image_url(get_field('last_project')['cover'], 'last-project'); ?>" alt="Новый проект"></a>
            </div>
            <div class="last-project__logo">
               <a href="<?= get_field('last_project')['link']; ?>"><img src="<?= wp_get_attachment_image_url(get_field('last_project')['logo'], 'full'); ?>" alt=""></a>
            </div>
            <div class="cross last-project__cross last-project__cross--one">
               <img src="<?php bloginfo('template_url')?>/img/general/cross.svg" alt="" rel="nofollow">
            </div>
            <div class="cross last-project__cross last-project__cross--two">
               <img src="<?php bloginfo('template_url')?>/img/general/cross.svg" alt="" rel="nofollow">
            </div>
            <div class="line line--color last-project__line last-project__line--one"></div>
            <div class="line line--color last-project__line last-project__line--two"></div>
           
            <div class="dotted last-project__dotted last-project__dotted--two">
               <img src="<?php bloginfo('template_url')?>/img/general/dotted.svg" alt="" rel="nofollow">
            </div>
         </div>
      </div>
   </div>
</section>
