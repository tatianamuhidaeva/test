<section class="section contacts">
    <div class="container">
        <h2 class="section__title <?php echo 'section__title--'.$contacts['title_color']; ?> <?php echo $contacts['visible_title'] ? '' : 'invisible'; ?>"><?php echo $contacts['title']; ?></h2>
        <div class="contacts__blank contacts__blank--offset-lg">
            <adress class="contacts__grid vcard">
                <div class="contacts__col contacts__col--main">
                	<h3 class="invisible">Адрес</h3>
                    <div class="adr contacts__adr">
                    	<span class="adr__state locality">Россия, г. Иркутск</span>
                    	<span class="adr__street street-address">ул. 1-я Красноказачья, 119, 3 этаж</span>
                	</div>
                </div>
                <div class="contacts__col">
                	<h3 class="invisible">Номер телефона</h3>
                    <div class="contacts__tel">
                        <a href="callto:+7(3952)96-26-91" class="tel" onclick="ym(38838170, 'reachGoal', 'telefon'); return true;">+7(3952)96-26-91</a>
                    </div>
                    <div class="contacts__tel">
                        <a href="callto:+7(985)925-90-79" class="tel" onclick="ym(38838170, 'reachGoal', 'telefon'); return true;">+7(985)925-90-79</a>
                    </div>
                </div>
                <div class="contacts__col">
                    <h3 class="contacts__heading contacts__heading--lg">Сотрудничество</h3> 
                    <div class="contacts__email">
                        <a href="mailto:support@t-code.ru" class="email" onclick="ym(38838170, 'reachGoal', 'mail'); return true;">support@t-code.ru</a>
                    </div>
                </div>
            </adress>
        </div>
    </div>
    <?php get_template_part('components/contacts/map'); ?>
</section>