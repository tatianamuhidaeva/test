$(document).ready(function () {
  $(window).on('load', function () {
    $('#preloader').fadeOut();
    $('html, body').css('overflow', 'visible');
    $('.promo-text__word').first().addClass('animate');
    setTimeout(function () {
      $('#preloader').fadeOut();
      $('html, body').css('overflow', 'visible');

      if ($('html, body').is(':hidden')) {
        $(".promo-text__word").first().addClass("animate");
      }
    }, 7000);
  });
}); // function Loader(callback) {
// 	var self = this;
// 	var imitation = 0;
// 	var progressbar = Snap("svg#progress #progressbar");
// 	var preloader = $("#mbr-prealader");
// 	var imitationTimer;
// 	function hide() {
// 		$("body").css("overflow", "auto");
// 		preloader.addClass("preloader-hide");
// 	}
// 	self.preloaderHide = function () {
// 		console.log("In preloaderHide")
// 		clearInterval(imitationTimer);
// 		imitationTimer = setInterval(imitationProgress, 100);
// 	}
// 	function imitationProgress() {
// 		if (progressbar.attr("width") < 144) {
// 			progressbar.attr("width", imitation += Math.ceil(Math.random() * 4));
// 		} else {
// 			clearInterval(imitationTimer);
// 			progressbar.attr("width", 144);
// 			hide();
// 			console.log(typeof (callback));
// 			if (typeof (callback) === "function") {
// 				callback();
// 			}
// 		}
// 	}
// 	self.init = function () {
// 		preloader.height($(window).height());
// 		preloader.width($(window).width());
// 		progressbar.attr("width", 0);
// 		imitationTimer = setInterval(imitationProgress, 750);
// 	}
// }
// var loader = new Loader();
// loader.init();
// $(window).on("load", function () {
// 	loader.preloaderHide();
// });