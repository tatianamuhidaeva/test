<?php get_header(); the_post(); ?>
<?php 
    # Выводит шапку сайта. (components/header)
    get_template_part('components/header/view');
?>
<section class="case">
    <div class="container container--sm">
        <div class="case__description">
            <p><strong>Контекстная реклама</strong> – это реклама в поисковых системах, которая показывается только тем пользователям, кто в ней заинтересован. Например, мы с вами хотим найти «компьютерное кресло», тогда нам в поисковой выдаче будут показаны объявления, связанные с покупкой, изготовлением и продажей компьютерных кресел.</p>
            <p>Нет никаких ограничений по сфере деятельности или специфики бизнеса для показа ваших объявлений в Яндексе или Google: на сегодняшний день абсолютно все необходимые услуги или товары ищут в интернете, а это значит, что и ваши услуги кому-то будут полезны!</p>

            <span class="mx-auto text-center" rel="nofollow" role="presentation">
                <picture>
                    <source type="image/webp" srcset="<?php bloginfo('template_url')?>/img/general/yago.webp">
                    <img src="<?php bloginfo('template_url')?>/img/general/yago.png" alt="Яндекс Google">
                </picture>
            </span>
        </div>
    </div>
    <div class="container container--sm">
       <div class="case__text-block clearfix">
           <h2 class="case__title invisible">Рекламная кампания</h2>

           <span id="context-phone" class="animated" rel="nofollow" role="presentation">
               <picture>
                   <source type="image/webp" srcset="<?php bloginfo('template_url')?>/img/general/iphone.webp">
                   <img src="<?php bloginfo('template_url')?>/img/general/iphone.png" alt="Пример работы">
               </picture>
           </span>

           <div class="pt-10--tablet">
               <p>Оплата за рекламу производится исходя из цены клика. То есть по факту каждого зашедшего пользователя на ваш сайт, который перешел по рекламе. Цена клика, в свою очередь, зависит от конкуренции внутри площадки по вашим запросам. Чем больше конкуренции на площадке, и чем выше показывается ваше объявление, тем выше цена за его клик.</p>
               <p><strong>Более подробно о том, как работают<br>рекламные кампании вы можете<br>почитать <a href="<?php echo get_site_url().'/kontekstnaya-reklama-chto-eto'; ?>">в нашем блоге</a></strong></p>
           </div>
       </div>

       <div class="case__text-block mb-0">
            <h2 class="case__title case__title--center">Как работает контекстная реклама</h2>
            <p>Механизм работы рекламной кампании в <span style="color: #ff6f0f;">Яндекс.Директ</span> или <span style="color: #3359fe;">Google Adwords</span> достаточно прост. И самое главное – правильно настроенная контекстная реклама не требует постоянной модерации и отслеживания. Контекстная реклама может работать на вас без прикладывания к ней дополнительных усилий. Убедитесь сами!</p>
       </div>
    </div>
    
    <div class="slider case__slider" role="slider">
        <div class="slider__container">
            <?php get_template_part('components/case-slider/slider'); ?>
        </div>
    </div> 

    <div class="container">
        <div class="case__text-block">
            <h2 class="case__title case__title--center">Выгоды, понятные каждому клиенту</h2>
            <ul class="case__adv">
                <li class="case__adv-item">
                    <div class="case__adv-inner">
                        <span class="case__adv-icon" rel="nofollow" role="presentation">
                            <picture>
                                <source type="image/webp" srcset="<?php bloginfo('template_url')?>/img/general/icon-flash.webp">
                                <img src="<?php bloginfo('template_url')?>/img/general/icon-flash.png" alt="БЫСТРЫЙ РЕЗУЛЬТАТ">
                            </picture>
                        </span>
                        
                        <h3 class="case__adv-title">БЫСТРЫЙ РЕЗУЛЬТАТ</h3>
                        <p>Клиенты начнут видеть ваши объявления сразу после запуска рекламной кампании, а это значит, что они сразу начнут приходить за вашим предложением к вам на сайт.</p>
                    </div>
                </li>
                <li class="case__adv-item">
                    <div class="case__adv-inner">
                        <span class="case__adv-icon" rel="nofollow" role="presentation">
                            <picture>
                                <source type="image/webp" srcset="<?php bloginfo('template_url')?>/img/general/icon-pay.webp">
                                <img src="<?php bloginfo('template_url')?>/img/general/icon-pay.png" alt="Оплата только за действие">
                            </picture>
                        </span>

                        <h3 class="case__adv-title">Оплата только за действие</h3>
                        <p>20 000 человек может посмотреть ваше объявление в день, но всего 200 кликнуть по нему. Вы заплатите только за 200 кликов, потому что вы платите только за результат.</p>
                    </div>
                </li>
                <li class="case__adv-item">
                    <div class="case__adv-inner">
                        <span class="case__adv-icon" rel="nofollow" role="presentation">
                            <picture>
                                <source type="image/webp" srcset="<?php bloginfo('template_url')?>/img/general/icon-masson.webp">
                                <img src="<?php bloginfo('template_url')?>/img/general/icon-masson.png" alt="ТОЛЬКО ЦЕЛЕВАЯ АУДИТОРИЯ">
                            </picture>
                        </span>
                        
                        <h3 class="case__adv-title">ТОЛЬКО ЦЕЛЕВАЯ АУДИТОРИЯ</h3>
                        <p>Рекламные объявления показываются только тем, кто заинтересован в этом предложении и сам ищет по нему информацию. Вы просто оказываетесь в нужное время и в нужный час.</p>
                    </div>
                </li>
                <li class="case__adv-item">
                    <div class="case__adv-inner">
                        <span class="case__adv-icon" rel="nofollow" role="presentation">
                            <picture>
                                <source type="image/webp" srcset="<?php bloginfo('template_url')?>/img/general/icon-party.webp">
                                <img src="<?php bloginfo('template_url')?>/img/general/icon-party.png" alt="Широкий охват аудитории">
                            </picture>
                        </span>
                        
                        <h3 class="case__adv-title">Широкий охват аудитории</h3>
                        <p>Помимо поисковой системы ваши объявления увидят на сайтах партнеров: авито, одноклассники, почта Яндекс, mail.ru, афиша. </p>
                    </div>
                </li>
                <li class="case__adv-item">
                    <div class="case__adv-inner">
                        <span class="case__adv-icon" rel="nofollow" role="presentation">
                            <picture>
                                <source type="image/webp" srcset="<?php bloginfo('template_url')?>/img/general/icon-ironman.webp">
                                <img src="<?php bloginfo('template_url')?>/img/general/icon-ironman.png" alt="Мощные инструменты анализа">
                            </picture>
                        </span>
                        
                        <h3 class="case__adv-title">Мощные инструменты анализа</h3>
                        <p>Вы можете увидеть, что каждый посетитель делает на вашем сайте! Специальные инструменты аналитики, например, как Яндекс.Метрика, позволяют объективно оценивать работу вашей рекламной кампании: составлять отчеты по посещаемости, времени на сайте и даже формировать карту кликов.</p>
                    </div>
                </li>
            </ul>
        </div>
    </div>

    <div class="case-common case-common--kirvi">
        <div class="case-common__inner">
            <span id="kirvi-wall" class="case-common__img animated" rel="nofollow" role="presentation">
                <picture>
                    <source type="image/webp" srcset="<?php bloginfo('template_url')?>/img/general/kirvi-img.webp">
                    <img src="<?php bloginfo('template_url')?>/img/general/kirvi-img.png" alt="Кирпич в Иркутске">
                </picture>
            </span>
            <div class="case-common__blank">
                <span class="case-common__logo" rel="nofollow" role="presentation">
                    <picture>
                        <source type="image/webp" srcset="<?php bloginfo('template_url')?>/img/general/kirvi.webp">
                        <img src="<?php bloginfo('template_url')?>/img/general/kirvi.png" alt="Кирпич в Иркутске логотип">
                    </picture>
                </span>
                <div class="case-common__text">
                    <p>Например, как мы это сделали<br>для компании Кирпич в Иркутске</p>
                    <a href="<?php echo get_site_url().'/case/kirvi'; ?>" class="case-common__link">Посмотреть кейс</a>
                </div>
            </div>
        </div>
    </div>
</section>

<?php 
    # выводит секцию с формой обратной связи. (components/feedback/bid)
    bid(array(
        'visible_title' => false
    ));
?>

<footer class="case-footer pb-10">
    <nav class="case-footer__nav case-footer__nav--around">
        <a href="<?php echo get_site_url().'/design'; ?>" class="btn btn--back btn--white case-footer__back">Фирменный стиль</a>
        <a href="<?php echo get_site_url().'/smm'; ?>" class="btn btn--next btn--white case-footer__next">SMM</a>
    </nav>
</footer>

<?php get_footer(); ?>