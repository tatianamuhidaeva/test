<div class="alert" rel="nofollow" role="alert">
	<div class="alert__close">✖</div>
	<div class="alert__body">Спасибо!<br>Ваше сообщение отправлено</div>
</div>